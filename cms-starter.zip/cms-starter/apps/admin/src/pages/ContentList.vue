<script setup lang="ts">
import Icon from '@/components/Icon.vue';
import DataTable, {
  type DataTableColumn,
} from '@/components/DataTable.vue';
import { computed, onMounted, ref, watch } from 'vue';
import { RouterLink, useRoute, useRouter } from 'vue-router';
import { ApiError } from '@/lib/api';
import {
  contentApi,
  CONTENT_STATUSES,
  type Content,
  type ContentStatus,
  type ListContentParams,
} from '@/api/content';
import { contentTypesApi, type ContentType } from '@/api/content-types';
import { toast } from '@/composables/useToast';
import { useConfirm } from '@/composables/useConfirm';
import { useAuthStore } from '@/stores/auth';
import ContentTypePickerModal from '@/components/ContentTypePickerModal.vue';

const auth = useAuthStore();
const { confirm } = useConfirm();
const items = ref<Content[]>([]);
const types = ref<ContentType[]>([]);
const loading = ref(false);
const error = ref<string | null>(null);

// Offset-based numbered pagination (see DataTable). `limit` defaults to 10 and
// is user-adjustable via the footer rows-per-page selector.
const page = ref(1);
const limit = ref(10);
const total = ref(0);

const route = useRoute();
const router = useRouter();

// "+ New Content" type chooser. With a single content type there's nothing to
// choose, so the button skips the modal and goes straight to the editor.
const pickerOpen = ref(false);

function onNewContent(): void {
  const only = types.value.length === 1 ? types.value[0] : null;
  if (only) {
    void router.push({ name: 'content-create', params: { typeId: only.id } });
    return;
  }
  pickerOpen.value = true;
}

function onPickType(t: ContentType): void {
  pickerOpen.value = false;
  void router.push({ name: 'content-create', params: { typeId: t.id } });
}

// `?create=1` opens the picker on arrival — used by the Home quick action and
// the legacy /content/new redirect. The query is stripped first so back/refresh
// doesn't re-open the modal.
async function handleCreateQuery(): Promise<void> {
  if (route.query['create'] !== '1') return;
  const { create: _create, ...rest } = route.query;
  await router.replace({ query: rest });
  onNewContent();
}

function queryType(): string {
  const t = route.query['type'];
  return typeof t === 'string' ? t : '';
}
function queryStatus(): ContentStatus | '' {
  const s = route.query['status'];
  return typeof s === 'string' &&
    (CONTENT_STATUSES as readonly string[]).includes(s)
    ? (s as ContentStatus)
    : '';
}

const filterStatus = ref<ContentStatus | ''>(queryStatus());
const filterTypeId = ref<string>(queryType());
const filterQ = ref('');
const filterSubmittedBy = ref<'' | 'user' | 'guest'>('');

const typesById = computed(() =>
  Object.fromEntries(types.value.map((t) => [t.id, t])),
);

const columns: DataTableColumn[] = [
  { key: 'title', label: 'Title', width: '46%' },
  { key: 'type', label: 'Type' },
  { key: 'status', label: 'Status' },
  { key: 'updated', label: 'Updated' },
  { key: 'actions', label: 'Actions', width: '132px', align: 'right' },
];

function listParams(): ListContentParams {
  return {
    page: page.value,
    limit: limit.value,
    ...(filterStatus.value ? { status: filterStatus.value } : {}),
    ...(filterTypeId.value ? { contentTypeId: filterTypeId.value } : {}),
    ...(filterQ.value.trim() ? { q: filterQ.value.trim() } : {}),
    ...(filterSubmittedBy.value
      ? { submittedBy: filterSubmittedBy.value }
      : {}),
  };
}

async function loadTypes(): Promise<void> {
  try {
    const res = await contentTypesApi.list();
    types.value = res.data;
  } catch {
    // non-fatal — filter dropdown stays empty
  }
}

async function load(): Promise<void> {
  loading.value = true;
  error.value = null;
  try {
    const res = await contentApi.list(listParams());
    items.value = res.data;
    total.value = res.pagination.total;
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load';
  } finally {
    loading.value = false;
  }
}

let searchTimer: ReturnType<typeof setTimeout> | null = null;
function onSearchInput(v: string): void {
  filterQ.value = v;
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    page.value = 1;
    void load();
  }, 250);
}

// Public-site origin from the session (auth.publicWebUrl is sourced from
// siteSettings.siteUrl on the API side). Null = not configured.
const publicOrigin = computed<string | null>(() => {
  const fromAuth = auth.publicWebUrl;
  return fromAuth && fromAuth.length > 0
    ? fromAuth.replace(/\/$/, '')
    : null;
});

function previewTemplate(item: Content): string | null {
  return typesById.value[item.contentTypeId]?.previewPath ?? null;
}

// Mirror of buildPreviewPath in apps/api/src/lib/preview-routes.ts. Kept
// inline to avoid a workspace dep just for one regex substitution. `{category}`
// falls back to `uncategorized` to match the API helper and the public
// articleUrl() behaviour.
function substituteSlug(
  template: string,
  slug: string,
  categorySlug?: string | null,
): string {
  const category =
    categorySlug && categorySlug.length > 0 ? categorySlug : 'uncategorized';
  return template
    .replace(/\{slug\}/g, encodeURIComponent(slug))
    .replace(/\{category\}/g, encodeURIComponent(category));
}

function viewOnSiteDisabledReason(item: Content): string | null {
  if (!previewTemplate(item)) {
    return 'Preview not configured for this content type — set previewPath on the content type to enable.';
  }
  if (!publicOrigin.value) {
    return 'Public site URL is not configured — set Site URL in Site Settings.';
  }
  return null;
}

async function onViewOnSite(item: Content): Promise<void> {
  const reason = viewOnSiteDisabledReason(item);
  if (reason) {
    toast.error(reason);
    return;
  }
  const template = previewTemplate(item);
  if (!template || !publicOrigin.value) return; // narrows for TS
  try {
    if (item.status === 'published') {
      // Public URL, no token needed — opens what an anonymous visitor sees.
      const url = `${publicOrigin.value}${substituteSlug(template, item.slug, item.primaryCategorySlug)}`;
      window.open(url, '_blank', 'noopener');
      return;
    }
    // Drafts/scheduled/archived need a signed preview token — same code path
    // as the editor's Preview button.
    const { data } = await contentApi.previewToken(item.id);
    window.open(data.previewUrl, '_blank', 'noopener');
  } catch (e) {
    if (
      e instanceof ApiError &&
      e.status === 422 &&
      e.body &&
      typeof e.body === 'object' &&
      'error' in e.body &&
      e.body.error === 'no_public_route'
    ) {
      toast.error('Preview is not configured for this content type yet.');
      return;
    }
    toast.error(e instanceof Error ? e.message : 'Failed to open preview');
  }
}

async function onDelete(item: Content): Promise<void> {
  const ok = await confirm({
    title: 'Delete content',
    message: `Delete "${item.title}"? This cannot be undone.`,
    confirmLabel: 'Delete',
    tone: 'danger',
  });
  if (!ok) return;
  try {
    await contentApi.remove(item.id);
    toast.success('Content deleted');
    // Reload so the count + pagination stay accurate; step back a page if we
    // just removed the last row on the final page.
    if (items.value.length === 1 && page.value > 1) page.value -= 1;
    else await load();
  } catch (e) {
    toast.error(
      `Delete failed: ${
        e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'unknown'
      }`,
    );
  }
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}
function humanize(s: string): string {
  return s.replace(/_/g, ' ');
}

const hasFilters = computed(
  () =>
    !!(
      filterQ.value.trim() ||
      filterStatus.value ||
      filterTypeId.value ||
      filterSubmittedBy.value
    ),
);
const emptyTitle = computed(() =>
  hasFilters.value ? 'No content matches your filters' : 'No content yet',
);
const emptyHint = computed(() =>
  hasFilters.value
    ? 'Try adjusting your search or filters'
    : 'Click "New Content" to create one',
);
const resultLabel = computed(() =>
  loading.value
    ? 'Loading…'
    : `${total.value} item${total.value === 1 ? '' : 's'}`,
);

watch([filterStatus, filterTypeId, filterSubmittedBy], () => {
  page.value = 1;
  void load();
});
watch([page, limit], () => void load());
watch(
  () => route.query['type'],
  () => {
    filterTypeId.value = queryType();
  },
);
watch(
  () => route.query['status'],
  () => {
    filterStatus.value = queryStatus();
  },
);

watch(
  () => route.query['create'],
  (v) => {
    // Re-entry while already mounted (e.g. Home quick action from this tab).
    if (v === '1' && !loading.value) void handleCreateQuery();
  },
);

onMounted(async () => {
  await Promise.all([loadTypes(), load()]);
  await handleCreateQuery();
});
</script>

<template>
  <section>
    <header class="page-header">
      <div>
        <h1 class="page-title">Content</h1>
        <p class="page-subtitle">Manage and review all content</p>
      </div>
      <button
        type="button"
        class="btn btn-primary"
        data-testid="new-content"
        @click="onNewContent"
      >
        <Icon name="plus" :size="14" /> New Content
      </button>
    </header>

    <ContentTypePickerModal
      :open="pickerOpen"
      :types="types"
      @close="pickerOpen = false"
      @select="onPickType"
    />

    <p v-if="error" class="load-error">{{ error }}</p>

    <DataTable
      v-model:page="page"
      v-model:limit="limit"
      :rows="items"
      :columns="columns"
      :row-key="(r: Content) => r.id"
      :total="total"
      :loading="loading"
      :result-label="resultLabel"
      :empty-title="emptyTitle"
      :empty-hint="emptyHint"
      empty-icon="📄"
    >
      <template #toolbar>
        <label class="search-input">
          <Icon name="search" :size="13" />
          <input
            type="search"
            placeholder="Search content…"
            :value="filterQ"
            @input="(e) => onSearchInput((e.target as HTMLInputElement).value)"
          />
        </label>
        <select v-model="filterStatus" class="select-filter">
          <option value="">All statuses</option>
          <option v-for="s in CONTENT_STATUSES" :key="s" :value="s">
            {{ humanize(s) }}
          </option>
        </select>
        <select v-model="filterTypeId" class="select-filter">
          <option value="">All types</option>
          <option v-for="t in types" :key="t.id" :value="t.id">
            {{ t.name }}
          </option>
        </select>
        <select v-model="filterSubmittedBy" class="select-filter">
          <option value="">All sources</option>
          <option value="user">Submitted by: logged-in user</option>
          <option value="guest">Submitted by: guest</option>
        </select>
      </template>

      <template #cell:title="{ row }">
        <RouterLink
          :to="{ name: 'content-edit', params: { id: (row as Content).id } }"
          class="row-link"
        >
          {{ (row as Content).title }}
        </RouterLink>
        <span class="slug">{{ (row as Content).slug }}</span>
      </template>

      <template #cell:type="{ row }">
        {{ typesById[(row as Content).contentTypeId]?.name ?? '—' }}
      </template>

      <template #cell:status="{ row }">
        <span class="badge" :class="`badge-${(row as Content).status}`">
          {{ humanize((row as Content).status) }}
        </span>
      </template>

      <template #cell:updated="{ row }">
        <span class="mono cell-muted">
          {{ formatDate((row as Content).updatedAt) }}
        </span>
      </template>

      <template #cell:actions="{ row }">
        <div class="actions">
          <RouterLink
            :to="{ name: 'content-edit', params: { id: (row as Content).id } }"
            class="icon-btn"
            title="Edit"
            aria-label="Edit"
          >
            <Icon name="edit" />
          </RouterLink>
          <button
            type="button"
            class="icon-btn"
            :class="{
              'icon-btn--disabled': !!viewOnSiteDisabledReason(row as Content),
            }"
            :disabled="!!viewOnSiteDisabledReason(row as Content)"
            :aria-disabled="!!viewOnSiteDisabledReason(row as Content)"
            :title="
              viewOnSiteDisabledReason(row as Content) ??
              ((row as Content).status === 'published'
                ? 'View on public site'
                : 'Preview on public site (signed link)')
            "
            :aria-label="
              (row as Content).status === 'published'
                ? 'View on public site'
                : 'Preview on public site'
            "
            @click="onViewOnSite(row as Content)"
          >
            <Icon name="external" />
          </button>
          <button
            type="button"
            class="icon-btn icon-btn--danger"
            title="Delete"
            aria-label="Delete"
            @click="onDelete(row as Content)"
          >
            <Icon name="trash" />
          </button>
        </div>
      </template>
    </DataTable>
  </section>
</template>

<style scoped>
.row-link {
  font-weight: 500;
  text-decoration: none;
  color: var(--fg);
}
.row-link:hover {
  color: var(--accent-hover);
}
.slug {
  display: block;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
  color: var(--text-tertiary);
  margin-top: 2px;
}
.cell-muted {
  color: var(--muted);
  white-space: nowrap;
}
.load-error {
  margin: 0 0 12px;
  color: var(--danger);
  font-size: 13px;
}
.actions {
  display: flex;
  align-items: center;
  gap: 4px;
  justify-content: flex-end;
}

/* Read-as-disabled visual for the View-on-site button when the content
 * type has no previewPath. The default .icon-btn:disabled styling can look
 * like a transient loading state; this makes the unavailability obvious. */
.icon-btn--disabled {
  color: var(--text-tertiary) !important;
  background: var(--surface-muted, transparent) !important;
  cursor: not-allowed !important;
  opacity: 0.55;
}
.icon-btn--disabled:hover {
  background: var(--surface-muted, transparent) !important;
  color: var(--text-tertiary) !important;
}
</style>
