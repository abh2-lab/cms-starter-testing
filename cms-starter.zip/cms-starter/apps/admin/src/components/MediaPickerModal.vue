<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { mediaApi, uploadMedia, type Media } from '@/api/media';

const props = withDefaults(
  defineProps<{
    multiple?: boolean;
    title?: string;
  }>(),
  { multiple: false, title: 'Select media' },
);

const emit = defineEmits<{
  close: [];
  select: [items: Media[]];
}>();

const items = ref<Media[]>([]);
const loading = ref(false);
const loadingMore = ref(false);
const error = ref<string | null>(null);
const nextCursor = ref<string | null>(null);
const hasMore = ref(false);

const selectedIds = ref<Set<string>>(new Set());
const uploading = ref(false);
const uploadPct = ref(0);
const fileInput = ref<HTMLInputElement | null>(null);

async function loadFirst(): Promise<void> {
  loading.value = true;
  error.value = null;
  try {
    const res = await mediaApi.list({ limit: 40 });
    items.value = res.data;
    nextCursor.value = res.pagination.nextCursor;
    hasMore.value = res.pagination.hasMore;
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load media';
  } finally {
    loading.value = false;
  }
}

async function loadMore(): Promise<void> {
  if (!nextCursor.value || loadingMore.value) return;
  loadingMore.value = true;
  try {
    const res = await mediaApi.list({ limit: 40, cursor: nextCursor.value });
    items.value.push(...res.data);
    nextCursor.value = res.pagination.nextCursor;
    hasMore.value = res.pagination.hasMore;
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load more';
  } finally {
    loadingMore.value = false;
  }
}

function toggle(m: Media): void {
  if (props.multiple) {
    const next = new Set(selectedIds.value);
    if (next.has(m.id)) next.delete(m.id);
    else next.add(m.id);
    selectedIds.value = next;
  } else {
    // Single select → confirm immediately.
    emit('select', [m]);
  }
}

function confirm(): void {
  const chosen = items.value.filter((m) => selectedIds.value.has(m.id));
  emit('select', chosen);
}

function onPickFiles(): void {
  fileInput.value?.click();
}

async function onFilesChosen(e: Event): Promise<void> {
  const input = e.target as HTMLInputElement;
  const files = Array.from(input.files ?? []);
  input.value = '';
  if (files.length === 0) return;
  uploading.value = true;
  uploadPct.value = 0;
  error.value = null;
  try {
    // Upload sequentially so the single progress bar stays meaningful.
    for (const file of files) {
      const media = await uploadMedia(file, (pct) => {
        uploadPct.value = pct;
      });
      items.value.unshift(media);
      if (!props.multiple) {
        emit('select', [media]);
        return;
      }
      const next = new Set(selectedIds.value);
      next.add(media.id);
      selectedIds.value = next;
    }
  } catch (err) {
    error.value = err instanceof Error ? err.message : 'Upload failed';
  } finally {
    uploading.value = false;
  }
}

function isImage(m: Media): boolean {
  return m.mimeType.startsWith('image/');
}

function fileExt(name: string): string {
  const dot = name.lastIndexOf('.');
  return dot >= 0 ? name.slice(dot + 1).toUpperCase() : 'FILE';
}

onMounted(loadFirst);
</script>

<template>
  <div class="backdrop" @click.self="emit('close')">
    <div class="modal" role="dialog" aria-modal="true">
      <header class="modal-header">
        <h2>{{ title }}</h2>
        <div class="header-actions">
          <button type="button" class="btn btn--small" :disabled="uploading" @click="onPickFiles">
            {{ uploading ? `Uploading ${uploadPct}%` : 'Upload new' }}
          </button>
          <button type="button" class="close" aria-label="Close" @click="emit('close')">✕</button>
        </div>
        <input
          ref="fileInput"
          type="file"
          :multiple="multiple"
          class="hidden-input"
          @change="onFilesChosen"
        />
      </header>

      <p v-if="loading" class="muted">Loading…</p>
      <p v-else-if="error" class="error">{{ error }}</p>
      <p v-else-if="items.length === 0" class="muted">
        No media yet. Click <em>Upload new</em> to add a file.
      </p>

      <div v-else class="grid">
        <button
          v-for="m in items"
          :key="m.id"
          type="button"
          class="card"
          :class="{ 'card--selected': selectedIds.has(m.id) }"
          @click="toggle(m)"
        >
          <div class="thumb">
            <img v-if="isImage(m)" :src="m.url" :alt="m.altText ?? m.originalFilename" />
            <span v-else class="ext">{{ fileExt(m.originalFilename) }}</span>
          </div>
          <span v-if="multiple && selectedIds.has(m.id)" class="check">✓</span>
          <div class="card-name">{{ m.originalFilename }}</div>
        </button>
      </div>

      <div v-if="hasMore" class="load-more">
        <button type="button" class="btn btn--small" :disabled="loadingMore" @click="loadMore">
          {{ loadingMore ? 'Loading…' : 'Load more' }}
        </button>
      </div>

      <footer v-if="multiple" class="modal-footer">
        <span class="muted">{{ selectedIds.size }} selected</span>
        <div class="footer-actions">
          <button type="button" class="btn" @click="emit('close')">Cancel</button>
          <button
            type="button"
            class="btn btn--primary"
            :disabled="selectedIds.size === 0"
            @click="confirm"
          >
            Add selected
          </button>
        </div>
      </footer>
    </div>
  </div>
</template>

<style scoped>
.backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 60;
  padding: 2rem;
}
.modal {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 0.75rem;
  width: 56rem;
  max-width: 100%;
  max-height: 85vh;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1.25rem;
  overflow-y: auto;
}
.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
.modal-header h2 {
  margin: 0;
  font-size: 1.05rem;
}
.header-actions {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
.close {
  border: 0;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  font-size: 1rem;
}
.hidden-input {
  display: none;
}
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(8rem, 1fr));
  gap: 0.75rem;
}
.card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  padding: 0;
  border: 2px solid var(--border);
  border-radius: 0.5rem;
  background: transparent;
  cursor: pointer;
  overflow: hidden;
  text-align: left;
}
.card:hover {
  border-color: var(--accent);
}
.card--selected {
  border-color: var(--accent);
}
.thumb {
  aspect-ratio: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--border);
  overflow: hidden;
}
.thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ext {
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-size: 0.8125rem;
  color: var(--muted);
  font-weight: 600;
}
.check {
  position: absolute;
  top: 0.375rem;
  right: 0.375rem;
  width: 1.25rem;
  height: 1.25rem;
  border-radius: 999px;
  background: var(--accent);
  color: white;
  font-size: 0.75rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-name {
  font-size: 0.6875rem;
  padding: 0 0.375rem 0.375rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--fg);
}
.load-more {
  text-align: center;
}
.modal-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid var(--border);
  padding-top: 1rem;
}
.footer-actions {
  display: flex;
  gap: 0.5rem;
}
.muted {
  color: var(--muted);
  font-size: 0.875rem;
}
.error {
  color: #dc2626;
  font-size: 0.875rem;
}
.btn {
  display: inline-flex;
  align-items: center;
  padding: 0.5rem 0.875rem;
  border: 1px solid var(--border);
  border-radius: 0.375rem;
  background: transparent;
  color: var(--fg);
  font-size: 0.875rem;
  cursor: pointer;
}
.btn:hover {
  border-color: var(--accent);
  color: var(--accent);
}
.btn--small {
  padding: 0.3125rem 0.625rem;
  font-size: 0.8125rem;
}
.btn--primary {
  background: var(--accent);
  color: white;
  border-color: var(--accent);
}
.btn--primary:hover {
  background: transparent;
  color: var(--accent);
}
.btn--primary:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
</style>
