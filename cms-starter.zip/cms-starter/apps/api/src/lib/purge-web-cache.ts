import { env } from '@cms/config';
import { resolveSiteUrl } from './site-url.js';

// Best-effort purge of the public site's nitro route cache (SWR'd HTML)
// after a theme-override publish/reset. Mirrors the cache-invalidation
// fail-open contract everywhere else: the write already committed — a dead
// web container, a missing site URL, or an unset PURGE_SECRET must never
// fail the admin request. See apps/web/server/routes/api/_purge.post.ts.

type WarnLogger = { warn: (obj: unknown, msg: string) => void };

export async function purgeWebCache(
  log: WarnLogger,
  tenantId: string,
): Promise<void> {
  const secret = env.PURGE_SECRET;
  if (!secret || secret.length === 0) return; // purge disabled — no-op

  try {
    const siteUrl = await resolveSiteUrl(tenantId);
    if (!siteUrl) {
      log.warn({}, 'web cache purge skipped: site URL not configured');
      return;
    }
    const res = await fetch(`${siteUrl.replace(/\/$/, '')}/api/_purge`, {
      method: 'POST',
      headers: { 'x-purge-secret': secret },
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) {
      log.warn({ status: res.status }, 'web cache purge returned non-2xx');
    }
  } catch (err) {
    log.warn({ err }, 'web cache purge failed (fail-open)');
  }
}
