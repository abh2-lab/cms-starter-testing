// Neutral default Nuxt frontend for the CMS test stack.
//
// The public API is reached SAME-ORIGIN via a Nitro proxy (see routeRules
// below): the browser and SSR both call `/api/public/*` on this site's own
// origin and Nitro forwards to the API. No CORS, no public API URL to wire
// up — mirrors how the admin's nginx proxies /api. The proxy target is baked
// at build time: the Docker image sets NUXT_API_PROXY_TARGET=http://api:3000
// (compose service name), and non-Docker `pnpm dev` falls back to
// http://127.0.0.1:3000 (not "localhost") so Windows installs don't try ::1
// first — the API binds to 127.0.0.1 only, and a missed proxy lands every
// /api/public/* call on Vite's HMR socket, which returns 426 for any plain
// HTTP request and looks like the entire public site is broken.
const apiProxyTarget =
  process.env['NUXT_API_PROXY_TARGET'] || 'http://127.0.0.1:3000';

const isProd = process.env['NODE_ENV'] === 'production';

// The active theme layer is chosen by ACTIVE_THEME (same env @cms/config reads
// for the block palette): 'basic' = the neutral starter theme (the blank
// starter's .env sets this); anything else = the full Decode 'default' theme.
// themes/basic itself extends themes/default and overrides only the chrome +
// a few blocks, so the default layer must stay present.
const activeTheme =
  process.env['ACTIVE_THEME'] === 'basic' ? 'basic' : 'default';

export default defineNuxtConfig({
  // The active theme is a Nuxt layer. Everything visual (pages, components,
  // layouts, composables, utils, assets) plus the theme's CSS + fonts lives in
  // apps/web/themes/default; this host config keeps only infrastructure — the
  // API proxy, ISR routeRules, devServer — plus app.vue. Swapping the theme is
  // a matter of pointing this `extends` at a different layer.
  extends: [`./themes/${activeTheme}`],
  devtools: { enabled: true },
  devServer: {
    // API runs on :3000; web sits next to it. PORT wins when set so a second
    // dev instance (e.g. the Claude Preview verifier) can run beside the
    // primary `pnpm dev` one without fighting over 3001.
    port: Number(process.env['PORT'] || 3001),
  },
  app: {
    head: {
      // Generic document head. The brand <title> + fonts live in the theme
      // layer's config (apps/web/themes/default/nuxt.config.ts); Nuxt merges
      // app.head across layers.
      htmlAttrs: { lang: 'en' },
      meta: [
        { charset: 'utf-8' },
        {
          name: 'viewport',
          content:
            'width=device-width, initial-scale=1.0, viewport-fit=cover',
        },
        {
          name: 'description',
          content:
            'A minimal neutral public site exercising every CMS feature end-to-end.',
        },
      ],
    },
  },
  // The structure editor's iframe preview (theme engine v2.0) needs the
  // frame guard to vary per request, so the production security headers
  // (formerly a static routeRules '/**' headers block here) moved to
  // server/middleware/01.security-headers.ts. NUXT_ADMIN_ORIGIN (read there)
  // feeds the frame-ancestors allowance for preview requests.
  //
  // ISR matches the API's 300s public cache TTL so the layers cache together.
  // Production only — in dev the SWR cache swallows admin edits for up to
  // 5 minutes and produces confusing hydration mismatches against fresh data.
  // /article/** intentionally NOT cached at the Nuxt layer: the API response
  // is already cached in DragonflyDB, and a Nuxt-side HTML cache would also
  // store ?preview= responses, leaking draft renders to public visitors who
  // hit the same slug after a preview warmed the cache. The theme_preview
  // paths (articles + category/tag pages) are likewise un-cached here, so a
  // draft render can never be stored server-side.
  routeRules: {
    '/api/public/**': { proxy: `${apiProxyTarget}/api/public/**` },
    ...(isProd
      ? {
          '/': { swr: 300 },
          '/archive': { swr: 300 },
          '/archive/**': { swr: 300 },
          '/stories': { swr: 300 },
          '/stories/**': { swr: 300 },
        }
      : {}),
  },
});
