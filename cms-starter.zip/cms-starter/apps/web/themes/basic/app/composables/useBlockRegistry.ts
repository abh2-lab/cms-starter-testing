import type { Component } from 'vue';
import { BLOCK_REGISTRY as DEFAULT_REGISTRY } from '../../../default/app/composables/useBlockRegistry';
import BlockSiteNav from '~/components/blocks/BlockSiteNav.vue';
import BlockFooterColumns from '~/components/blocks/BlockFooterColumns.vue';
import BlockFooterBottom from '~/components/blocks/BlockFooterBottom.vue';
import BlockSearchOverlay from '~/components/blocks/BlockSearchOverlay.vue';
import BlockLatestNews from '~/components/blocks/BlockLatestNews.vue';

// The basic theme's block→component map. It reuses EVERY default block renderer
// (spread from the default layer's registry) and swaps only the site chrome for
// neutral versions. This is what makes the starter's header/footer plain while
// inheriting all the generic content blocks.
//
// Block components are resolved through this map (not by filename), so a neutral
// chrome override must live HERE, not just as a same-named .vue — and the paired
// BlockNode.vue in this layer imports THIS registry (via `~`) so every rendered
// block routes through it. A later self-contained pass replaces the relative
// import of the default registry with basic's own full set.
export type { ComposedBlock } from '../../../default/app/composables/useBlockRegistry';

export const BLOCK_REGISTRY: Readonly<Record<string, Component>> = {
  ...DEFAULT_REGISTRY,
  'site-nav': BlockSiteNav as Component,
  'footer-columns': BlockFooterColumns as Component,
  'footer-bottom': BlockFooterBottom as Component,
  'search-overlay': BlockSearchOverlay as Component,
  'latest-news': BlockLatestNews as Component,
};

export function useBlockRegistry(): typeof BLOCK_REGISTRY {
  return BLOCK_REGISTRY;
}
