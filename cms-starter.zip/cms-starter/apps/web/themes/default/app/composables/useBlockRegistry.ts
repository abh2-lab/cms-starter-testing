import { defineAsyncComponent, type Component } from 'vue';
import BlockHero from '~/components/blocks/BlockHero.vue';
import BlockHeroFeatured from '~/components/blocks/BlockHeroFeatured.vue';
import BlockLatestNews from '~/components/blocks/BlockLatestNews.vue';
import BlockFeatureStories from '~/components/blocks/BlockFeatureStories.vue';
import BlockEditorNotes from '~/components/blocks/BlockEditorNotes.vue';
import BlockFeaturedArticle from '~/components/blocks/BlockFeaturedArticle.vue';
import BlockImpactStats from '~/components/blocks/BlockImpactStats.vue';
import BlockCategoryStrip from '~/components/blocks/BlockCategoryStrip.vue';
import BlockNewsletterCta from '~/components/blocks/BlockNewsletterCta.vue';
// Theme-engine v1: field, container, and box block renderers (FSE primitives).
import BlockPostTitle from '~/components/blocks/BlockPostTitle.vue';
// BlockPostContent is lazy-loaded at the registry entry below (see note there).
import BlockFeaturedImage from '~/components/blocks/BlockFeaturedImage.vue';
import BlockPublishedAt from '~/components/blocks/BlockPublishedAt.vue';
import BlockPostAuthor from '~/components/blocks/BlockPostAuthor.vue';
import BlockArchiveTitle from '~/components/blocks/BlockArchiveTitle.vue';
import BlockGroup from '~/components/blocks/BlockGroup.vue';
import BlockQueryLoop from '~/components/blocks/BlockQueryLoop.vue';
import BlockPost from '~/components/blocks/BlockPost.vue';
// Theme-engine v1.5: archive re-blocking (post card + archive chrome).
import BlockPostCard from '~/components/blocks/BlockPostCard.vue';
import BlockArchiveHero from '~/components/blocks/BlockArchiveHero.vue';
import BlockArchiveManifesto from '~/components/blocks/BlockArchiveManifesto.vue';
import BlockDispatchBox from '~/components/blocks/BlockDispatchBox.vue';
import BlockEditorNotesColumn from '~/components/blocks/BlockEditorNotesColumn.vue';
// Theme-engine v1.5: site chrome (header/footer parts).
import BlockSiteNav from '~/components/blocks/BlockSiteNav.vue';
import BlockFooterColumns from '~/components/blocks/BlockFooterColumns.vue';
import BlockFooterBottom from '~/components/blocks/BlockFooterBottom.vue';
// Theme-engine v1.5: article chrome re-blocking.
import BlockPostHero from '~/components/blocks/BlockPostHero.vue';
import BlockEditorialNote from '~/components/blocks/BlockEditorialNote.vue';
import BlockArticleToc from '~/components/blocks/BlockArticleToc.vue';
import BlockPostTags from '~/components/blocks/BlockPostTags.vue';
import BlockEditorCredit from '~/components/blocks/BlockEditorCredit.vue';
import BlockRelatedPosts from '~/components/blocks/BlockRelatedPosts.vue';
import BlockAuthorBios from '~/components/blocks/BlockAuthorBios.vue';
import BlockSidebarNewsletter from '~/components/blocks/BlockSidebarNewsletter.vue';
import BlockEditorNotesPanel from '~/components/blocks/BlockEditorNotesPanel.vue';
// Events page blocks (the /events page is now dynamic).
import BlockEventsHero from '~/components/blocks/BlockEventsHero.vue';
import BlockPastEvents from '~/components/blocks/BlockPastEvents.vue';
import BlockEventsCta from '~/components/blocks/BlockEventsCta.vue';
// Theme-engine v2 Phase 4: system-page blocks (404/search/authors/contact).
import BlockNotFound from '~/components/blocks/BlockNotFound.vue';
import BlockSearchForm from '~/components/blocks/BlockSearchForm.vue';
import BlockSearchResults from '~/components/blocks/BlockSearchResults.vue';
import BlockAuthorGrid from '~/components/blocks/BlockAuthorGrid.vue';
import BlockContactForm from '~/components/blocks/BlockContactForm.vue';
// <gen:block-imports> — `pnpm gen:block` inserts new block component imports here. Keep this marker.
import BlockSearchOverlay from '~/components/blocks/BlockSearchOverlay.vue';
// </gen:block-imports>

// One composed block from the API render composer (apps/api/src/lib/
// compose-blocks.ts). The `data` is the loader's projected output; `children`
// is the nested subtree (omitted on leaves). Shared by BlockTree/BlockNode/
// PageView so there's a single front-end shape.
export interface ComposedBlock {
  id: string;
  key: string;
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
  children?: ComposedBlock[];
  error?: 'load_failed' | 'unknown_block' | 'max_depth' | 'budget_exceeded';
}

// Map of block_key → Vue component. The keys MUST match the meta.key values
// exported by the matching block in @cms/blocks/src/blocks/<key>.ts —
// adding a new block means landing a new pair (loader + Vue component) on
// the same key.
//
// Static map (not generated) on purpose: it's small, tree-shakes cleanly,
// and the IDE catches "block exists in API but not in renderer" mismatches
// at type-check time via the surrounding code. A future build-time check
// can compare this map against the manifest if drift becomes a concern.

// The auto-generated .vue type for SFC default exports surfaces as `any`
// at the import site under strict ESLint, even though vue-tsc resolves it
// to `DefineComponent` at type-check time. Cast to `Component` at the
// registry boundary so the consumer types stay clean.
export const BLOCK_REGISTRY: Readonly<Record<string, Component>> = {
  hero: BlockHero as Component,
  'hero-featured': BlockHeroFeatured as Component,
  'latest-news': BlockLatestNews as Component,
  'feature-stories': BlockFeatureStories as Component,
  'editor-notes': BlockEditorNotes as Component,
  'featured-article': BlockFeaturedArticle as Component,
  'impact-stats': BlockImpactStats as Component,
  'category-strip': BlockCategoryStrip as Component,
  'newsletter-cta': BlockNewsletterCta as Component,
  // FSE-style primitives. Field blocks read the current-post box; container/box
  // blocks render their children via the default slot (see BlockNode).
  'post-title': BlockPostTitle as Component,
  // Lazy-loaded: BlockPostContent → ContentBody → renderTiptap (@tiptap/html) is
  // a heavy chain that pulls Node built-ins (path/url/source-map-js) into the
  // client bundle. Code-split it so it loads ONLY when an article body renders —
  // keeping it (and the dev "module externalized" console warnings) off the
  // homepage and every other non-article page that uses the block registry.
  'post-content': defineAsyncComponent(
    () => import('~/components/blocks/BlockPostContent.vue'),
  ) as Component,
  'featured-image': BlockFeaturedImage as Component,
  'published-at': BlockPublishedAt as Component,
  'post-author': BlockPostAuthor as Component,
  // Lazy-loaded for the same reason as post-content: rich-text custom fields
  // render via ContentBody → renderTiptap, a heavy chain best code-split so it
  // only loads when a custom-field block actually renders.
  'custom-field': defineAsyncComponent(
    () => import('~/components/blocks/BlockCustomField.vue'),
  ) as Component,
  'archive-title': BlockArchiveTitle as Component,
  group: BlockGroup as Component,
  'query-loop': BlockQueryLoop as Component,
  post: BlockPost as Component,
  // Archive re-blocking (v1.5).
  'post-card': BlockPostCard as Component,
  'archive-hero': BlockArchiveHero as Component,
  'archive-manifesto': BlockArchiveManifesto as Component,
  'dispatch-box': BlockDispatchBox as Component,
  'editor-notes-column': BlockEditorNotesColumn as Component,
  // Site chrome (v1.5 parts).
  'site-nav': BlockSiteNav as Component,
  'footer-columns': BlockFooterColumns as Component,
  'footer-bottom': BlockFooterBottom as Component,
  // Article chrome (v1.5).
  'post-hero': BlockPostHero as Component,
  'editorial-note': BlockEditorialNote as Component,
  'article-toc': BlockArticleToc as Component,
  'post-tags': BlockPostTags as Component,
  'editor-credit': BlockEditorCredit as Component,
  'related-posts': BlockRelatedPosts as Component,
  'author-bios': BlockAuthorBios as Component,
  'sidebar-newsletter': BlockSidebarNewsletter as Component,
  'editor-notes-panel': BlockEditorNotesPanel as Component,
  // Events page blocks.
  'events-hero': BlockEventsHero as Component,
  'past-events': BlockPastEvents as Component,
  'events-cta': BlockEventsCta as Component,
  // System-page blocks (v2 Phase 4): 404 / search / authors / contact.
  'not-found': BlockNotFound as Component,
  'search-form': BlockSearchForm as Component,
  'search-results': BlockSearchResults as Component,
  'author-grid': BlockAuthorGrid as Component,
  'contact-form': BlockContactForm as Component,
  // <gen:block-registry> — `pnpm gen:block` inserts new block entries here. Keep this marker.
  'search-overlay': BlockSearchOverlay as Component,
  // </gen:block-registry>
};

export function useBlockRegistry(): typeof BLOCK_REGISTRY {
  return BLOCK_REGISTRY;
}
