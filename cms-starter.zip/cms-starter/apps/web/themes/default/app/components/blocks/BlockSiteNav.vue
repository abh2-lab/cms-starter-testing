<script setup lang="ts">
import { useCmsMenu, useSiteSettings } from '~/composables/useCmsFetch';
import { useSearchOverlay } from '~/composables/useSearchOverlay';
import { categoryUrl } from '~/utils/urls';

// Standalone block: the Decode site header. Markup, styles, and the
// menu/fallback data path moved verbatim from SiteHeader.vue (theme engine
// v1.5 re-blocking) — the whole navbar stays ONE component because the
// mobile-collapse + dropdown state is a single interactive organism. The
// nav LINKS come from the CMS menu named by options.menu_slug; the action
// labels/visibility come from the block's fields/options.
const props = defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();

interface NavLink {
  id: string;
  label: string;
  to: string;
  newTab: boolean;
}
interface NavNode extends NavLink {
  children: NavLink[];
}

function fieldStr(key: string, fallback: string): string {
  const v = props.fields[key];
  return typeof v === 'string' && v.length > 0 ? v : fallback;
}
// Visibility toggles default ON when the option is absent (old trees / code
// defaults) — only an explicit false hides an action.
function optionFlag(key: string): boolean {
  return props.options[key] !== false;
}

const menuSlug = computed(() => {
  const v = props.options['menu_slug'];
  return typeof v === 'string' && v.length > 0 ? v : 'main-nav';
});
const subscribeLabel = computed(() => fieldStr('subscribe_label', 'Subscribe'));
const signinLabel = computed(() => fieldStr('signin_label', 'Sign In'));
const showSubscribe = computed(() => optionFlag('show_subscribe'));
const showSearch = computed(() => optionFlag('show_search'));
const showSignin = computed(() => optionFlag('show_signin'));

// Logo via the shared site-settings slot (same useAsyncData key the layout
// uses — deduped, no extra request).
const { data: settings } = await useSiteSettings();

// CMS-managed navigation. useAsyncData dedupes by key and survives SSR. data is
// null when the menu is absent (404) — navItems falls back to FALLBACK_NAV.
const { data: menu } = await useCmsMenu(menuSlug.value);

function resolveUrl(item: {
  url: string | null;
  contentSlug: string | null;
}): string {
  if (item.url && item.url.length > 0) return item.url;
  if (item.contentSlug) return `/${item.contentSlug}`;
  return '#';
}

// Fallback nav — mirrors the Decode mock and the seed:menus defaults. Used only
// when the CMS has no active menu under menuSlug. categoryUrl() keeps these
// aligned with the theme's URL rules.
const FALLBACK_NAV: NavNode[] = [
  { id: 'home', label: 'Home', to: '/', newTab: false, children: [] },
  { id: 'events', label: 'Events', to: '/events', newTab: false, children: [] },
  {
    id: 'categories',
    label: 'Categories',
    to: '#',
    newTab: false,
    children: [
      { id: 'c1', label: 'Young Minds', to: categoryUrl('young-minds'), newTab: false },
      { id: 'c2', label: 'Digital State', to: categoryUrl('digital-state'), newTab: false },
      { id: 'c3', label: 'Labour', to: categoryUrl('labour'), newTab: false },
      { id: 'c4', label: 'Life', to: categoryUrl('life'), newTab: false },
      { id: 'c5', label: 'Decode Explains', to: categoryUrl('decode-explains'), newTab: false },
      { id: 'c6', label: 'Voices', to: categoryUrl('voices'), newTab: false },
    ],
  },
  {
    id: 'about',
    label: 'About',
    to: '#',
    newTab: false,
    children: [
      { id: 'a1', label: 'About Decode', to: '/about', newTab: false },
      { id: 'a2', label: 'Mission', to: '/mission', newTab: false },
      { id: 'a3', label: 'How to Pitch', to: '/how-to-pitch', newTab: false },
    ],
  },
];

const navItems = computed<NavNode[]>(() => {
  const items = menu.value?.items;
  if (!items || items.length === 0) return FALLBACK_NAV;
  return items.map((it) => ({
    id: it.id,
    label: it.label,
    to: it.children.length > 0 ? '#' : resolveUrl(it),
    newTab: it.openInNewTab,
    children: it.children.map((c) => ({
      id: c.id,
      label: c.label,
      to: resolveUrl(c),
      newTab: c.openInNewTab,
    })),
  }));
});

// Collapsing nav state for the mobile breakpoint.
const navOpen = ref(false);
// Which dropdown is open, keyed by node id (only one open at a time). Hover-
// triggered on desktop, click-triggered on mobile.
const openDropdown = ref<string | null>(null);

function toggleNav(): void {
  navOpen.value = !navOpen.value;
  if (!navOpen.value) openDropdown.value = null;
}
function toggleDropdown(id: string): void {
  openDropdown.value = openDropdown.value === id ? null : id;
}
function openMenu(id: string): void {
  openDropdown.value = id;
}
function closeMenus(): void {
  openDropdown.value = null;
}
function closeAll(): void {
  navOpen.value = false;
  openDropdown.value = null;
}

// The header search button opens the global search overlay (the Decode
// "What are you looking for?" modal) rather than navigating. The overlay block
// lives in the same header part and routes to /search on submit.
const { open: openSearch } = useSearchOverlay();
function onSearchClick(): void {
  closeAll();
  openSearch();
}

// External logo URL — matches what the published Decode mocks use. A
// publisher running this install would either upload a media row and let
// settings.logoUrl drive it, or replace this string with their own.
const FALLBACK_LOGO = 'https://www.boomlive.in/images/decode_new.png';
</script>

<template>
  <nav class="site-header" :class="{ 'nav-open': navOpen }">
    <div class="container-custom nav-row">
      <NuxtLink to="/" class="navbar-brand" @click="closeAll">
        <img
          :src="settings?.logoUrl || FALLBACK_LOGO"
          :alt="settings?.siteName || 'Decode'"
          class="header-logo"
          loading="eager"
          decoding="async"
        />
      </NuxtLink>

      <div class="navbar-collapse" :class="{ open: navOpen }">
        <ul class="navbar-nav">
          <li
            v-if="showSignin"
            class="nav-item nav-item-signin nav-item-mobile-only"
          >
            <button type="button" class="btn-signin btn-signin-mobile" @click="closeAll">
              {{ signinLabel }}
            </button>
          </li>

          <template v-for="node in navItems" :key="node.id">
            <li v-if="node.children.length === 0" class="nav-item">
              <NuxtLink
                :to="node.to"
                class="nav-link"
                :target="node.newTab ? '_blank' : undefined"
                :rel="node.newTab ? 'noopener noreferrer' : undefined"
                @click="closeAll"
              >{{ node.label }}</NuxtLink>
            </li>
            <li
              v-else
              class="nav-item dropdown"
              :class="{ show: openDropdown === node.id }"
              @mouseenter="openMenu(node.id)"
              @mouseleave="closeMenus"
            >
              <button
                type="button"
                class="nav-link dropdown-toggle"
                :aria-expanded="openDropdown === node.id"
                @click="toggleDropdown(node.id)"
              >
                {{ node.label }}
              </button>
              <ul class="dropdown-menu-custom" :class="{ show: openDropdown === node.id }">
                <li v-for="child in node.children" :key="child.id">
                  <NuxtLink
                    :to="child.to"
                    class="dropdown-item"
                    :target="child.newTab ? '_blank' : undefined"
                    :rel="child.newTab ? 'noopener noreferrer' : undefined"
                    @click="closeAll"
                  >
                    {{ child.label }}
                  </NuxtLink>
                </li>
              </ul>
            </li>
          </template>

          <li v-if="showSignin" class="nav-item nav-item-desktop-only">
            <button type="button" class="btn-signin">{{ signinLabel }}</button>
          </li>
        </ul>
      </div>

      <div class="header-actions">
        <NuxtLink
          v-if="showSubscribe"
          to="/newsletters"
          class="btn-subscribe"
          @click="closeAll"
        >
          {{ subscribeLabel }}
        </NuxtLink>
        <button
          v-if="showSearch"
          type="button"
          class="btn-search"
          aria-label="Search"
          aria-haspopup="dialog"
          @click="onSearchClick"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="icon-sm"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </button>
        <div class="header-divider" />
        <button
          type="button"
          class="navbar-toggler"
          aria-label="Toggle navigation"
          :aria-expanded="navOpen"
          @click="toggleNav"
        >
          <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M4 6h16M4 12h16m-7 6h7"
            />
          </svg>
        </button>
      </div>
    </div>
  </nav>
</template>

<style scoped>
.site-header {
  background-color: #121212;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  height: 80px;
  position: sticky;
  top: 0;
  z-index: 1000;
  padding: 0;
}
.container-custom {
  width: 100%;
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.nav-row {
  display: flex;
  align-items: center;
  height: 100%;
  gap: 24px;
}

.navbar-brand {
  display: inline-flex;
  align-items: center;
  line-height: 0;
  text-decoration: none;
  flex-shrink: 0;
}
.header-logo {
  height: 24px;
  width: auto;
}
@media (min-width: 768px) {
  .header-logo {
    height: 32px;
  }
}

/* ─── Desktop nav ─────────────────────────────────────────── */
.navbar-collapse {
  flex: 1;
  display: flex;
  justify-content: flex-end;
}
.navbar-nav {
  display: flex;
  align-items: center;
  gap: 32px;
  list-style: none;
  padding: 0;
  margin: 0;
}
.nav-item {
  position: relative;
}
.nav-item-mobile-only {
  display: none;
}

.nav-link {
  color: #a3a3a3;
  font-weight: 500;
  font-size: 15px;
  transition: color 0.2s;
  padding: 8px 0;
  text-decoration: none;
  background: none;
  border: none;
  cursor: pointer;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
}
.nav-link:hover,
.nav-link:focus {
  color: #fff;
}
.nav-link.router-link-active {
  color: #fff;
}

/* Down-chevron after dropdown toggles */
.dropdown-toggle::after {
  content: '';
  display: inline-block;
  width: 10px;
  height: 10px;
  margin-left: 6px;
  background: url("data:image/svg+xml,%3Csvg fill='none' stroke='%23A3A3A3' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M19 9l-7 7-7-7' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")
    no-repeat center;
  background-size: contain;
  opacity: 0.5;
  transition: transform 0.2s;
  vertical-align: middle;
}
.dropdown.show > .dropdown-toggle::after,
.dropdown:hover > .dropdown-toggle::after {
  transform: rotate(180deg);
}

/* Dropdown menu */
.dropdown-menu-custom {
  position: absolute;
  top: 100%;
  left: 0;
  background: #1a1a1a;
  border: 1px solid #262626;
  min-width: 200px;
  border-radius: 4px;
  margin: 10px 0 0 0;
  padding: 0;
  list-style: none;
  display: none;
  z-index: 1001;
}
.dropdown-menu-custom.show {
  display: block;
}
/* Invisible bridge so the dropdown doesn't close when the cursor moves
   from the trigger to the menu */
.dropdown-menu-custom::before {
  content: '';
  position: absolute;
  bottom: 100%;
  left: 0;
  right: 0;
  height: 10px;
}
.dropdown-item {
  display: block;
  padding: 12px 20px;
  color: #a3a3a3;
  font-size: 13px;
  font-weight: 600;
  border-bottom: 1px solid #262626;
  transition: background 0.2s, color 0.2s;
  text-decoration: none;
}
.dropdown-menu-custom li:last-child .dropdown-item {
  border-bottom: none;
}
.dropdown-item:hover,
.dropdown-item:focus {
  background: #d34135;
  color: #fff;
}

/* ─── Right-side actions ──────────────────────────────────── */
.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.btn-subscribe {
  background-color: #d34135;
  color: #fff;
  padding: 8px 16px;
  border-radius: 4px;
  font-weight: 700;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background 0.2s;
  white-space: nowrap;
  text-decoration: none;
}
@media (min-width: 768px) {
  .btn-subscribe {
    padding: 10px 32px;
    font-size: 14px;
  }
}
.btn-subscribe:hover {
  background-color: #b2342a;
  color: #fff;
}

.btn-search {
  background: none;
  border: none;
  color: #9ca3af;
  cursor: pointer;
  padding: 4px;
  transition: color 0.2s;
}
.btn-search:hover {
  color: #fff;
}

.btn-signin {
  color: #a3a3a3;
  font-weight: 600;
  font-size: 15px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  transition: color 0.2s;
  white-space: nowrap;
  font-family: inherit;
}
.btn-signin:hover {
  color: #fff;
}

.header-divider {
  height: 24px;
  width: 1px;
  background: rgba(255, 255, 255, 0.1);
  margin: 0 4px;
  display: none;
}
.navbar-toggler {
  background: none;
  border: none;
  color: #9ca3af;
  padding: 4px;
  cursor: pointer;
  transition: color 0.2s;
  display: none;
}
.navbar-toggler:hover {
  color: #fff;
}

.icon-sm {
  width: 24px;
  height: 24px;
}

/* ─── Mobile ──────────────────────────────────────────────── */
@media (max-width: 991.98px) {
  .container-custom {
    padding: 0 16px;
  }
  .header-divider,
  .navbar-toggler {
    display: block;
  }
  .nav-item-desktop-only {
    display: none;
  }
  .nav-item-mobile-only {
    display: block;
  }

  .navbar-collapse {
    position: fixed;
    top: 80px;
    left: 0;
    width: 100%;
    background: #121212;
    z-index: 999;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    padding: 20px;
    max-height: calc(100vh - 80px);
    overflow-y: auto;
    display: none;
  }
  .navbar-collapse.open {
    display: block;
  }
  .navbar-nav {
    flex-direction: column;
    gap: 0;
    align-items: stretch;
  }
  .nav-item {
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  }
  .nav-link {
    padding: 12px 0;
    color: #fff;
    width: 100%;
    text-align: left;
  }

  /* Mobile dropdown: static, indented, click-to-open */
  .dropdown-menu-custom {
    position: static;
    background: transparent;
    border: none;
    margin: 0;
    padding: 0 0 0 16px;
    display: none;
  }
  .dropdown-menu-custom.show {
    display: block;
  }
  .dropdown-item {
    border-bottom: none;
    padding: 8px 0;
    color: #888;
    font-size: 14px;
  }

  /* Sign In on mobile — accent red, sits above Home */
  .btn-signin-mobile {
    color: #d34135;
    font-size: 15px;
    font-weight: 700;
    padding: 12px 0;
    width: 100%;
    text-align: left;
  }
  .nav-item-signin {
    border-bottom: 1px solid rgba(211, 65, 53, 0.2);
  }
}
</style>
