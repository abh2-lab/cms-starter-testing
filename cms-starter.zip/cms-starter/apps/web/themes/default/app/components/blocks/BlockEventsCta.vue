<script setup lang="ts">
// Renderer for the `events-cta` block — the dark "Priority access" card at the
// bottom of the /events page, ported from the static page. Fixed copy.
defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();
</script>

<template>
  <section class="block-events-cta">
    <div class="container-custom">
      <div class="cta-dark-card">
        <div>
          <span class="section-label-sm">For Members</span>
          <h3 class="cta-dark-title">Priority access to every event</h3>
          <p class="cta-dark-text">
            Members receive priority invitations before events open to the public
            — including closed briefings where our reporters walk through how an
            investigation was built.
          </p>
        </div>
        <NuxtLink to="/about" class="btn-cta-red">
          Become a Member for priority access
        </NuxtLink>
      </div>
    </div>
  </section>
</template>

<style scoped>
.block-events-cta {
  background-color: #faf7f2;
  padding: 0 0 40px;
}
.container-custom {
  width: 100%;
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px 40px;
}
@media (max-width: 768px) {
  .container-custom {
    padding: 0 16px 40px;
  }
}
.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d32f2f;
  margin-bottom: 20px;
  display: block;
}
.cta-dark-card {
  background-color: #121212;
  color: #e5e5e5;
  border-radius: 16px;
  padding: 48px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}
@media (max-width: 768px) {
  .cta-dark-card {
    padding: 32px 24px;
  }
}
.cta-dark-title {
  font-size: 28px;
  font-weight: 700;
  color: #f3f0e0;
  margin: 8px 0 0 0;
}
@media (max-width: 768px) {
  .cta-dark-title {
    font-size: 22px;
  }
}
.cta-dark-text {
  font-size: 15px;
  line-height: 1.7;
  color: #9ca3af;
  margin: 8px 0 0 0;
}
.btn-cta-red {
  display: inline-block;
  background-color: #d32f2f;
  color: #fff;
  padding: 14px 32px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 15px;
  text-decoration: none;
  white-space: nowrap;
  align-self: flex-start;
  transition: background-color 0.2s;
}
.btn-cta-red:hover {
  background-color: #b5352a;
  color: #fff;
}
</style>
