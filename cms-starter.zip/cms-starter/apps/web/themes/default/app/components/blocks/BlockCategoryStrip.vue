<script setup lang="ts">
import { categoryUrl } from '~/utils/urls';

// Category strip — Decode mock styling. Icon-in-circle, cream card with
// red on-hover state that flips the icon + label to white. SVG glyphs
// keyed by slug match the mockup's set; unknown slugs fall back to a
// generic folder icon.

interface Fields {
  title?: string;
}
interface BlockOptions {
  _placeholder?: never;
}
interface Item {
  label: string;
  slug: string;
}
interface Data {
  items: Item[];
}

const props = defineProps<{
  fields: Fields;
  options: BlockOptions;
  data: Data | null;
}>();

const items = computed<Item[]>(() => props.data?.items ?? []);
</script>

<template>
  <section v-if="items.length > 0" class="block-category-strip">
    <div class="container-custom">
      <div class="section-heading-row">
        <h2 class="section-heading">
          {{ fields.title ?? 'Read by theme' }}
        </h2>
        <div class="section-heading-line" aria-hidden="true"></div>
      </div>
      <div class="category-scroll-container">
        <NuxtLink
          v-for="item in items"
          :key="item.slug"
          :to="categoryUrl(item.slug)"
          class="category-card"
        >
          <div class="category-icon-box">
            <svg
              v-if="item.slug === 'young-minds'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
              />
            </svg>
            <svg
              v-else-if="item.slug === 'digital-state'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
              />
            </svg>
            <svg
              v-else-if="item.slug === 'labour'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              />
            </svg>
            <svg
              v-else-if="item.slug === 'life'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
              />
            </svg>
            <svg
              v-else-if="item.slug === 'decode-explains'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            <svg
              v-else-if="item.slug === 'voices'"
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              />
            </svg>
            <svg
              v-else
              class="category-icon"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
              />
            </svg>
          </div>
          <span class="category-label">{{ item.label }}</span>
        </NuxtLink>
      </div>
    </div>
  </section>
</template>

<style scoped>
.block-category-strip {
  padding: 32px 0;
}
.container-custom {
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.section-heading-row {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}
.section-heading {
  font-size: 24px;
  font-weight: 700;
  color: #000;
  text-transform: uppercase;
  letter-spacing: -0.02em;
  margin: 0;
  white-space: nowrap;
}
.section-heading-line {
  height: 2px;
  flex: 1;
  background: rgba(0, 0, 0, 0.05);
}

.category-scroll-container {
  display: flex;
  gap: 1.5rem;
  width: 100%;
}
.category-card {
  flex: 1;
  min-width: 0;
  background: #faf9f2;
  border: 1px solid #e5e4da;
  padding: 2rem 1rem;
  border-radius: 16px;
  text-align: center;
  transition: 0.3s;
  text-decoration: none;
  color: inherit;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.category-icon-box {
  width: 60px;
  height: 60px;
  background: #eeebe0;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1rem;
  transition: 0.3s;
}
.category-icon {
  width: 24px;
  height: 24px;
  color: #d34135;
  transition: color 0.3s;
}
.category-label {
  font-size: 14px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  transition: color 0.3s;
}
.category-card:hover {
  background: #d34135;
  transform: translateY(-8px);
  border-color: #d34135;
  color: #fff;
}
.category-card:hover .category-icon-box {
  background: rgba(255, 255, 255, 0.2);
}
.category-card:hover .category-icon {
  color: white;
}
.category-card:hover .category-label {
  color: white;
}

@media (max-width: 900px) {
  .category-scroll-container {
    overflow-x: auto;
    scroll-snap-type: x mandatory;
    padding-bottom: 4px;
  }
  .category-card {
    flex: 0 0 160px;
    scroll-snap-align: start;
  }
}
</style>
