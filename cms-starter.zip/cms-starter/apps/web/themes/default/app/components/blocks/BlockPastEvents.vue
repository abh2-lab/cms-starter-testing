<script setup lang="ts">
// Renderer for the `past-events` block — the "Past Events" card grid, ported
// from the old static /events page so the design is preserved now that the page
// is block-driven. Reads the section heading from `fields` and the event list
// from `data` (the loader provides it). A card with no recap_url shows a static
// title (no link / arrow).
interface PastEvent {
  type_label: string;
  type_variant: 'investigation' | 'forum';
  image: string;
  overlay_label: string;
  accent_light?: boolean;
  title: string;
  description: string;
  recap_url?: string;
}
interface Fields {
  eyebrow?: string;
  title?: string;
}
interface Data {
  events: PastEvent[];
}

const props = defineProps<{
  fields: Fields;
  options: Record<string, unknown>;
  data: Data | null;
}>();

const eyebrow = computed(() => props.fields.eyebrow ?? 'From the archive');
const title = computed(() => props.fields.title ?? 'Past Events');
const events = computed<PastEvent[]>(() => props.data?.events ?? []);
</script>

<template>
  <section class="block-past-events">
    <div class="container-custom events-cream-inner">
      <span class="section-label-sm section-label-muted">{{ eyebrow }}</span>
      <h2 class="page-section-title">{{ title }}</h2>
      <div class="events-grid">
        <article v-for="(ev, i) in events" :key="i" class="event-card">
          <div class="event-img-box">
            <div class="event-label-box">
              <span
                class="event-label-link"
                :class="ev.type_variant === 'forum' ? 'lbl-forum' : 'lbl-investigation'"
              >
                {{ ev.type_label }}
              </span>
            </div>
            <img
              loading="lazy"
              decoding="async"
              :src="ev.image"
              class="event-img"
              :alt="ev.overlay_label"
            />
            <div class="event-card-overlay">
              <div
                class="event-card-accent-line"
                :class="{ 'event-card-accent-light': ev.accent_light }"
              ></div>
              <div class="event-card-overlay-label">{{ ev.overlay_label }}</div>
            </div>
          </div>
          <a
            v-if="ev.recap_url"
            :href="ev.recap_url"
            target="_blank"
            rel="noopener"
            class="event-title"
          >{{ ev.title }}</a>
          <span v-else class="event-title event-title-static">{{ ev.title }}</span>
          <p class="event-description">{{ ev.description }}</p>
          <div class="event-footer">
            <span class="event-meta">Past Event</span>
            <a
              v-if="ev.recap_url"
              :href="ev.recap_url"
              target="_blank"
              rel="noopener"
              class="event-btn"
              aria-label="Open recap"
            >&#8599;</a>
          </div>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.block-past-events {
  background-color: #faf7f2;
  padding: 40px 0;
}
.container-custom {
  width: 100%;
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.events-cream-inner {
  padding: 40px 40px;
}
@media (max-width: 768px) {
  .container-custom {
    padding: 0 16px;
  }
}

.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d32f2f;
  margin-bottom: 20px;
  display: block;
}
.section-label-muted {
  color: #888 !important;
}
.page-section-title {
  font-size: 32px;
  font-weight: 700;
  color: #121212;
  margin: 8px 0 24px 0;
}
@media (max-width: 768px) {
  .page-section-title {
    font-size: 26px;
  }
}

.events-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 28px;
}
@media (max-width: 768px) {
  .events-grid {
    grid-template-columns: 1fr;
  }
}

.event-card {
  background: #faf9f2;
  border-radius: 28px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  border: none;
  transition: 0.4s ease;
  position: relative;
  height: 100%;
}
.event-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 30px 60px -12px rgba(0, 0, 0, 0.08);
}
.event-img-box {
  position: relative;
  width: 100%;
  aspect-ratio: 1280 / 768;
  border-radius: 22px;
  overflow: hidden;
  margin-bottom: 20px;
}
.event-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.event-label-box {
  position: absolute;
  top: -1px;
  right: -1px;
  background: #faf9f2;
  padding: 8px 14px 14px 14px;
  border-bottom-left-radius: 24px;
  z-index: 5;
}
.event-label-link {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
}
.event-title {
  font-size: 20px;
  font-weight: 700;
  color: #121212;
  line-height: 1.3;
  margin: 0 16px 8px;
  display: block;
  text-decoration: none;
}
.event-title:hover {
  color: #d32f2f;
}
.event-title-static {
  cursor: default;
}
.event-description {
  font-size: 14px;
  color: #666;
  line-height: 1.5;
  margin: 0 16px 16px;
}
.event-footer {
  margin: auto 16px 12px;
  padding-top: 16px;
  border-top: 1px solid #eeebe0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.event-meta {
  font-size: 10px;
  font-weight: 700;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
.event-btn {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: #eeebe0;
  border: 1px solid #e5e4da;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  font-size: 16px;
  text-decoration: none;
  color: #121212;
}
.event-card:hover .event-btn {
  background: #000;
  color: #fff;
  border-color: #000;
}
.event-card-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 16px 20px;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.75));
  pointer-events: none;
}
.event-card-accent-line {
  width: 40px;
  height: 3px;
  background-color: #d32f2f;
  margin-bottom: 8px;
  border-radius: 2px;
}
.event-card-accent-light {
  background-color: #f3f0e0;
}
.event-card-overlay-label {
  font-size: 13px;
  font-weight: 600;
  color: #fff;
  letter-spacing: 0.02em;
}
.lbl-investigation {
  color: #d32f2f !important;
}
.lbl-forum {
  color: #2563eb !important;
}
</style>
