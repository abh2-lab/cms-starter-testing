<script setup lang="ts">
// Standalone block: the footer's bottom bar — © year + copyright line and a
// contact email. Markup + styles moved verbatim from SiteFooter.vue (theme
// engine v1.5 re-blocking); the copy comes from fields, the year stays
// computed.
const props = defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();

function fieldStr(key: string, fallback: string): string {
  const v = props.fields[key];
  return typeof v === 'string' && v.length > 0 ? v : fallback;
}

const copyrightText = computed(() =>
  fieldStr('copyright_text', 'Decode. A BOOM initiative. All rights reserved.'),
);
const contactEmail = computed(() =>
  fieldStr('contact_email', 'corrections@decode.in'),
);

const currentYear = computed(() => new Date().getFullYear());
</script>

<template>
  <div class="footer-bottom">
    <span>&copy; {{ currentYear }} {{ copyrightText }}</span>
    <span>{{ contactEmail }}</span>
  </div>
</template>

<style scoped>
.footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #4b5563;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
@media (min-width: 768px) {
  .footer-bottom {
    flex-direction: row;
    justify-content: space-between;
  }
}
</style>
