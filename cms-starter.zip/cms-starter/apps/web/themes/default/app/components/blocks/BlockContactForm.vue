<script setup lang="ts">
// Contact Form block — the /contact page body (theme engine v2 Phase 4). Markup
// + submit logic moved verbatim from contact.vue. POSTs to
// /api/public/submissions, saving a draft of `content_type_slug` (which must
// allow public submissions) for review. Heading, intro, button + success copy
// are editable fields.
interface Fields {
  heading?: string;
  lede?: string;
  button_label?: string;
  success_message?: string;
}
interface Options {
  content_type_slug?: string;
}

const props = defineProps<{
  fields: Fields;
  options: Options;
  data: unknown;
}>();

const contentTypeSlug = computed(() =>
  typeof props.options.content_type_slug === 'string' &&
  props.options.content_type_slug.length > 0
    ? props.options.content_type_slug
    : 'article',
);

const heading = computed(() => props.fields.heading ?? 'Contact');
const lede = computed(
  () =>
    props.fields.lede ??
    'Send us a message. Submissions are saved as drafts in admin for review.',
);
const buttonLabel = computed(() => props.fields.button_label ?? 'Send');
const successMessage = computed(
  () => props.fields.success_message ?? 'Thanks — your message was received.',
);

interface FormState {
  name: string;
  email: string;
  subject: string;
  message: string;
}

const form = reactive<FormState>({
  name: '',
  email: '',
  subject: '',
  message: '',
});

type Status = 'idle' | 'submitting' | 'success' | 'rate-limited' | 'error';
const status = ref<Status>('idle');
const errorMessage = ref<string | null>(null);

interface SubmissionResponse {
  success?: boolean;
  message?: string;
  error?: string;
}

const onSubmit = async (e: Event): Promise<void> => {
  e.preventDefault();
  if (status.value === 'submitting') return;
  status.value = 'submitting';
  errorMessage.value = null;
  try {
    await $fetch<SubmissionResponse>('/api/public/submissions/', {
      method: 'POST',
      body: {
        title: form.subject || `Contact: ${form.name}`,
        body: form.message,
        submitter_name: form.name,
        submitter_email: form.email,
        content_type_slug: contentTypeSlug.value,
      },
    });
    status.value = 'success';
    form.name = '';
    form.email = '';
    form.subject = '';
    form.message = '';
  } catch (err: unknown) {
    const e2 = err as { statusCode?: number; data?: { error?: string } };
    if (e2?.statusCode === 429) {
      status.value = 'rate-limited';
    } else {
      status.value = 'error';
      errorMessage.value =
        e2?.data?.error ?? 'Something went wrong. Please try again.';
    }
  }
};
</script>

<template>
  <section class="container contact">
    <h1>{{ heading }}</h1>
    <p class="lede">{{ lede }}</p>

    <form class="contact-form" novalidate @submit="onSubmit">
      <label>
        <span>Name</span>
        <input v-model="form.name" type="text" required maxlength="200" />
      </label>
      <label>
        <span>Email</span>
        <input v-model="form.email" type="email" required maxlength="320" />
      </label>
      <label>
        <span>Subject</span>
        <input v-model="form.subject" type="text" maxlength="500" />
      </label>
      <label>
        <span>Message</span>
        <textarea
          v-model="form.message"
          rows="6"
          required
          maxlength="20000"
        ></textarea>
      </label>

      <button
        type="submit"
        class="btn-primary"
        :disabled="status === 'submitting'"
      >
        {{ status === 'submitting' ? 'Sending…' : buttonLabel }}
      </button>

      <p v-if="status === 'success'" class="form-success">
        {{ successMessage }}
      </p>
      <p v-else-if="status === 'rate-limited'" class="form-error">
        Too many submissions from this address. Please try again later.
      </p>
      <p v-else-if="status === 'error'" class="form-error">
        {{ errorMessage }}
      </p>
    </form>
  </section>
</template>

<style scoped>
.contact {
  padding: 40px 20px 60px;
  max-width: 600px;
}
h1 {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 8px;
}
.lede {
  color: var(--muted);
  margin-bottom: 24px;
}
.contact-form {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.contact-form label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 13px;
  font-weight: 600;
}
.contact-form input,
.contact-form textarea {
  font-family: inherit;
  font-size: 15px;
  padding: 8px 10px;
  border: 1px solid var(--border);
  border-radius: var(--radius);
  background: var(--surface);
  color: var(--text);
}
.contact-form input:focus,
.contact-form textarea:focus {
  outline: 2px solid var(--accent);
  outline-offset: -1px;
  border-color: var(--accent);
}
.contact-form button {
  align-self: flex-start;
}
.form-success {
  color: #047857;
  font-size: 14px;
}
.form-error {
  color: #b91c1c;
  font-size: 14px;
}
</style>
