<script setup lang="ts">
import type { StoryDetail } from '~/composables/useCmsFetch';
import { articleUrl } from '~/utils/urls';

// Hero-featured masthead — Decode mock styling. Dark background, cream
// title, editorial-note callout, large rotating "READ NOW" badge on the
// left outer edge, yellow date tag on the bottom-left. Mirrors the .hero-*
// classes in the published mockup's styles.css.

interface Fields {
  kicker_override?: string;
  editorial_note?: string;
  date_label?: string;
}
interface BlockOptions {
  content_type?: string;
  slug?: string;
}
interface Data {
  story: StoryDetail | null;
}

const props = defineProps<{
  fields: Fields;
  options: BlockOptions;
  data: Data | null;
}>();

const story = computed(() => props.data?.story ?? null);

// Canonical article URL. story.primaryCategorySlug arrives from the
// hero-featured loader's StoryDetail payload (commit 1.2 of the
// flat-URL wave) so we can build /<category>/<article> without
// walking the taxonomy array here.
const articleHref = computed(() =>
  story.value
    ? articleUrl(story.value.slug, story.value.primaryCategorySlug)
    : '/',
);

const kicker = computed<string | null>(() => {
  if (props.fields.kicker_override && props.fields.kicker_override.length > 0) {
    return props.fields.kicker_override;
  }
  const cf = story.value?.customFields ?? {};
  const v = cf['kicker'];
  return typeof v === 'string' && v.length > 0 ? v : null;
});

// hero URL has two possible homes depending on who built the payload:
//   - BlockContentDetail (block loader, packages/blocks/src/types.ts):
//     heroImageUrl at TOP LEVEL. This is what `data.story` actually is at
//     runtime when a page block loads its own content.
//   - StoryDetail (/api/public/content endpoint): the same URL is spliced
//     INTO customFields.heroImageUrl by content.ts so admin previews of a
//     standalone article can read it from one place.
// `data.story` is typed as StoryDetail here for the shared interface, so
// we read top-level via an assertion and fall back to customFields for the
// preview-path. An earlier version only checked customFields, which is why
// the home page's hero block silently rendered no image (the block-loader
// payload doesn't splice into customFields).
const heroUrl = computed<string | null>(() => {
  const s = story.value;
  if (!s) return null;
  const top = (s as { heroImageUrl?: unknown }).heroImageUrl;
  if (typeof top === 'string' && top.length > 0) return top;
  const cf = s.customFields ?? {};
  const cfV = cf['heroImageUrl'];
  return typeof cfV === 'string' && cfV.length > 0 ? cfV : null;
});

// "20 Nov / 2025" → day="20", month="Nov", year="2025"
const datePieces = computed<{
  day: string | null;
  month: string | null;
  year: string | null;
}>(() => {
  const raw = (props.fields.date_label ?? '').trim();
  if (raw.length === 0) return { day: null, month: null, year: null };
  // Accept "20 Nov / 2025" or "20 Nov 2025"
  const m = raw.match(/^(\d{1,2})\s+([A-Za-z]+)\s*[/]?\s*(\d{4})?\s*$/);
  if (m) return { day: m[1] ?? null, month: m[2] ?? null, year: m[3] ?? null };
  return { day: null, month: null, year: raw };
});
</script>

<template>
  <section class="hero-section">
    <div v-if="story" class="container-custom">
      <div class="hero-container">
        <div class="content-side">
          <NuxtLink
            v-if="kicker"
            :to="articleHref"
            class="lbl-investigation hero-kicker-label"
          >
            {{ kicker }}
          </NuxtLink>
          <NuxtLink :to="articleHref" class="hero-title-link">
            <h1 class="hero-title">{{ story.title }}</h1>
          </NuxtLink>
          <div v-if="fields.editorial_note" class="hero-editorial-note">
            <div class="hero-editorial-header">
              <svg
                class="hero-editorial-icon"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M12 19l7-7 3 3-7 7-3-3z M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"
                />
              </svg>
              <span class="hero-editorial-label">Editorial Note: Why read this</span>
            </div>
            <p class="hero-editorial-text">{{ fields.editorial_note }}</p>
          </div>
        </div>
        <div class="image-wrap">
          <img
            v-if="heroUrl"
            :src="heroUrl"
            :alt="story.title"
            class="hero-img"
            loading="eager"
            decoding="async"
          />
          <NuxtLink
            :to="articleHref"
            class="hero-img-overlay-link"
            :aria-label="`Read: ${story.title}`"
          />
          <NuxtLink :to="articleHref" class="rotating-btn">
            <div class="rotating-text">
              <svg viewBox="0 0 100 100" class="rotating-svg">
                <path
                  id="circlePath"
                  d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
                  fill="transparent"
                />
                <text
                  font-size="9"
                  fill="white"
                  font-weight="bold"
                  letter-spacing="1"
                >
                  <textPath href="#circlePath">
                    READ NOW &bull; READ NOW &bull; READ NOW &bull;
                  </textPath>
                </text>
              </svg>
            </div>
            <span class="rotating-btn-arrow">&#8599;</span>
          </NuxtLink>
          <div
            v-if="datePieces.day || datePieces.month || datePieces.year"
            class="yellow-tag"
          >
            <span v-if="datePieces.day" class="yellow-tag-day">
              {{ datePieces.day }}
            </span>
            <div
              v-if="datePieces.day && (datePieces.month || datePieces.year)"
              class="date-divider"
            />
            <div v-if="datePieces.month || datePieces.year" class="yellow-tag-right">
              {{ datePieces.month }}
              <br v-if="datePieces.month && datePieces.year" />
              <span v-if="datePieces.year" class="yellow-tag-year">
                {{ datePieces.year }} //
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="empty container-custom">
      <p>
        <strong>Hero featured block:</strong>
        no story selected. Edit this page and set a content_type + slug.
      </p>
    </div>
  </section>
</template>

<style scoped>
.hero-section {
  background-color: #121212;
  color: #e5e5e5;
  padding-bottom: 20px;
}
.container-custom {
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.hero-container {
  display: grid;
  grid-template-columns: 1.15fr 0.85fr;
  min-height: 60vh;
  align-items: start;
  padding-top: 30px;
}
.content-side {
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  padding-right: 20px;
}

.lbl-investigation {
  color: #d34135 !important;
}
.hero-kicker-label {
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.4em;
  margin-bottom: 16px;
  display: block;
  transition: opacity 0.2s;
  text-decoration: none;
}
.hero-kicker-label:hover {
  opacity: 0.8;
}

.hero-title-link {
  color: inherit;
  text-decoration: none;
}
.hero-title {
  font-size: 64px;
  font-weight: 600;
  line-height: 1.1;
  color: #f3f0e0;
  margin: 0 0 24px 0;
  transition: color 0.2s;
}
.hero-title-link:hover .hero-title {
  color: #d34135;
}

.hero-editorial-note {
  border-left: 2px solid #d34135;
  background: rgba(255, 255, 255, 0.03);
  padding: 20px;
  max-width: 640px;
}
.hero-editorial-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}
.hero-editorial-icon {
  width: 16px;
  height: 16px;
  color: #d34135;
}
.hero-editorial-label {
  color: #d34135;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
}
.hero-editorial-text {
  color: #9ca3af;
  font-size: 18px;
  line-height: 1.6;
  margin: 0;
}

.image-wrap {
  aspect-ratio: 1280 / 768;
  position: relative;
  border-radius: 4px;
}
.image-wrap img.hero-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  border-radius: inherit;
}
.hero-img-overlay-link {
  position: absolute;
  inset: 0;
  z-index: 1;
  display: block;
  border-radius: 4px;
}

.rotating-btn {
  position: absolute;
  left: -65px;
  top: 50%;
  transform: translateY(-50%);
  width: 130px;
  height: 130px;
  z-index: 50;
  background: #121212;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(255, 255, 255, 0.1);
  text-decoration: none;
}
.rotating-text {
  position: absolute;
  width: 100%;
  height: 100%;
  animation: rotate 15s linear infinite;
}
.rotating-svg {
  width: 100%;
  height: 100%;
}
.rotating-btn-arrow {
  font-size: 24px;
  color: #fff;
}
@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.yellow-tag {
  background-color: #f0f370;
  color: #000;
  display: inline-flex;
  align-items: center;
  padding: 10px 22px;
  position: absolute;
  bottom: 30px;
  left: -45px;
  z-index: 60;
  transition: all 0.3s ease;
}
.yellow-tag-day {
  font-size: 30px;
  font-weight: 700;
}
.date-divider {
  height: 28px;
  width: 1px;
  background-color: #000;
  margin: 0 12px;
  opacity: 0.2;
}
.yellow-tag-right {
  font-size: 10px;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: -0.03em;
  line-height: 1.2;
}
.yellow-tag-year {
  color: #d34135;
}

.empty {
  padding: 24px;
  color: #9ca3af;
  border: 1px dashed rgba(255, 255, 255, 0.15);
  border-radius: 6px;
}

@media (max-width: 992px) {
  .hero-container {
    grid-template-columns: 1fr;
  }
  .hero-container .image-wrap {
    order: -1;
    width: 100%;
    margin-top: 0;
    border-radius: 0;
  }
  .hero-container .content-side {
    order: 1;
    padding: 28px 0 0 0;
  }
  .hero-title {
    font-size: 40px;
  }
  .rotating-btn {
    transform: scale(0.65) !important;
    left: 12px !important;
    top: auto !important;
    bottom: 20px !important;
  }
  .yellow-tag {
    left: auto !important;
    right: 0 !important;
    bottom: 0 !important;
    transform: scale(0.85);
    transform-origin: right bottom;
  }
}
</style>
