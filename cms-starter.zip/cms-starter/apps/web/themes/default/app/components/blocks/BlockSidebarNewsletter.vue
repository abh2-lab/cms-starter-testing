<script setup lang="ts">
// Standalone block: the compact newsletter CTA card from the article's right
// rail. Markup + styles moved verbatim from ArticleSidebar.vue (theme engine
// v1.5 re-blocking); the copy comes from fields.
const props = defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();

function fieldStr(key: string, fallback: string): string {
  const v = props.fields[key];
  return typeof v === 'string' && v.length > 0 ? v : fallback;
}

const label = computed(() => fieldStr('label', 'Newsletter'));
const title = computed(() => fieldStr('title', 'Decode in Your Inbox'));
const text = computed(() =>
  fieldStr(
    'text',
    'Investigations, explainers, and occasional notes from our reporters — sent when the work warrants it. Free.',
  ),
);
const buttonLabel = computed(() => fieldStr('button_label', 'Subscribe'));
const signupEmail = computed(() =>
  fieldStr('signup_email', 'subscribe@decode.in'),
);
const note = computed(() => fieldStr('note', 'No spam. Unsubscribe anytime.'));
</script>

<template>
  <div class="sidebar-card sidebar-cta">
    <div class="sidebar-cta-label">{{ label }}</div>
    <div class="sidebar-cta-title">{{ title }}</div>
    <p class="sidebar-cta-text">
      {{ text }}
    </p>
    <form
      class="sidebar-newsletter-form"
      :action="`mailto:${signupEmail}`"
      method="post"
      enctype="text/plain"
    >
      <input
        type="email"
        required
        placeholder="Your email address"
        class="sidebar-newsletter-input"
      />
      <button type="submit" class="sidebar-newsletter-btn">
        {{ buttonLabel }}
      </button>
    </form>
    <div class="sidebar-newsletter-note">{{ note }}</div>
  </div>
</template>

<style scoped>
.sidebar-card {
  background: #faf7f2;
  border: 1px solid rgba(0, 0, 0, 0.06);
  border-radius: 22px;
  padding: 24px;
  margin-bottom: 12px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
}
.sidebar-cta-label {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: #d34135;
  margin-bottom: 4px;
}
.sidebar-cta-title {
  font-size: 18px;
  font-weight: 700;
  color: #121212;
  margin-bottom: 8px;
}
.sidebar-cta-text {
  font-size: 14px;
  line-height: 1.6;
  color: #555;
  margin-bottom: 16px;
}
.sidebar-newsletter-form {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.sidebar-newsletter-input {
  padding: 12px 20px;
  border: 1px solid rgba(0, 0, 0, 0.1);
  border-radius: 50px;
  font-size: 14px;
  font-family: inherit;
  background: rgba(255, 255, 255, 0.6);
}
.sidebar-newsletter-input:focus {
  outline: none;
  border-color: #121212;
}
.sidebar-newsletter-btn {
  padding: 12px;
  background-color: #121212;
  color: #fff;
  border: none;
  border-radius: 50px;
  font-weight: 700;
  font-size: 14px;
  font-family: inherit;
  cursor: pointer;
  transition: background-color 0.2s;
}
.sidebar-newsletter-btn:hover {
  background-color: #d34135;
}
.sidebar-newsletter-note {
  font-size: 12px;
  color: #888;
  margin-top: 4px;
}
</style>
