<script setup lang="ts">
import { useCmsMenu, useSiteSettings } from '~/composables/useCmsFetch';
import { categoryUrl } from '~/utils/urls';

// Standalone block: the footer's main grid — brand column (logo, about
// blurb, social icons), CMS-menu link columns, and the newsletter signup
// welded into the LAST link column's iteration. Markup, styles, and the
// menu/fallback data path moved verbatim from SiteFooter.vue (theme engine
// v1.5 re-blocking); the previously hardcoded copy now comes from fields.
// One block for the whole grid: brand + link columns are siblings inside one
// CSS grid, unsplittable without restructuring the DOM.
const props = defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();

interface FooterLink {
  id: string;
  label: string;
  to: string;
  newTab: boolean;
}
interface FooterColumn {
  id: string;
  heading: string;
  links: FooterLink[];
}

function fieldStr(key: string, fallback: string): string {
  const v = props.fields[key];
  return typeof v === 'string' && v.length > 0 ? v : fallback;
}

const aboutText = computed(() =>
  fieldStr(
    'about_text',
    'Decode is an independent investigative publication examining how technology shapes power, labour, childhood, identity, and truth in India. Reader-supported. Editorially independent.',
  ),
);
const socialLinks = computed(() =>
  [
    { id: 'twitter', label: 'Twitter', url: fieldStr('twitter_url', '#') },
    { id: 'instagram', label: 'Instagram', url: fieldStr('instagram_url', '#') },
    { id: 'youtube', label: 'YouTube', url: fieldStr('youtube_url', '#') },
  ].filter((s) => s.url.length > 0),
);
const newsletterHeading = computed(() =>
  fieldStr('newsletter_heading', 'Stay Updated'),
);
const newsletterEmail = computed(() =>
  fieldStr('newsletter_email', 'subscribe@decode.in'),
);
const menuSlug = computed(() => {
  const v = props.options['menu_slug'];
  return typeof v === 'string' && v.length > 0 ? v : 'footer-nav';
});

const { data: settings } = await useSiteSettings();
const { data: menu } = await useCmsMenu(menuSlug.value);

function resolveUrl(item: {
  url: string | null;
  contentSlug: string | null;
}): string {
  if (item.url && item.url.length > 0) return item.url;
  if (item.contentSlug) return `/${item.contentSlug}`;
  return '#';
}

// Fallback columns — mirror the Decode mock and the seed:menus defaults. Used
// only when the CMS has no active menu under menuSlug. /about is the temporary
// landing for membership-shaped links until the public auth/payments phase.
const FALLBACK_COLUMNS: FooterColumn[] = [
  {
    id: 'explore',
    heading: 'Explore',
    links: [
      { id: 'e1', label: 'Young Minds', to: categoryUrl('young-minds'), newTab: false },
      { id: 'e2', label: 'Digital State', to: categoryUrl('digital-state'), newTab: false },
      { id: 'e3', label: 'Labour', to: categoryUrl('labour'), newTab: false },
      { id: 'e4', label: 'Life', to: categoryUrl('life'), newTab: false },
    ],
  },
  {
    id: 'decode',
    heading: 'Decode',
    links: [
      { id: 'd1', label: 'About Us', to: '/about', newTab: false },
      { id: 'd2', label: 'Our Team', to: '/authors', newTab: false },
      { id: 'd3', label: 'Mission', to: '/mission', newTab: false },
      { id: 'd4', label: 'How to Pitch', to: '/how-to-pitch', newTab: false },
      { id: 'd5', label: 'Events', to: '/events', newTab: false },
    ],
  },
  {
    id: 'support',
    heading: 'Support',
    links: [
      { id: 's1', label: 'Become a Member', to: '/about', newTab: false },
      { id: 's2', label: 'Gift a Membership', to: '/about', newTab: false },
      { id: 's3', label: 'Share a Tip', to: '/tipline', newTab: false },
    ],
  },
];

const columns = computed<FooterColumn[]>(() => {
  const items = menu.value?.items;
  if (!items || items.length === 0) return FALLBACK_COLUMNS;
  return items.map((it) => ({
    id: it.id,
    heading: it.label,
    links: it.children.map((c) => ({
      id: c.id,
      label: c.label,
      to: resolveUrl(c),
      newTab: c.openInNewTab,
    })),
  }));
});

const FALLBACK_LOGO = 'https://www.boomlive.in/images/decode_new.png';
</script>

<template>
  <div class="footer-cols">
    <div class="footer-col footer-col-brand">
      <img
        :src="settings?.logoUrl || FALLBACK_LOGO"
        :alt="settings?.siteName || 'Decode'"
        class="footer-logo"
        loading="lazy"
        decoding="async"
      />
      <p class="footer-about">
        {{ aboutText }}
      </p>
      <div class="footer-social-row">
        <template v-for="social in socialLinks" :key="social.id">
          <a
            :href="social.url"
            class="social-icon"
            :aria-label="social.label"
          >
            <svg
              v-if="social.id === 'twitter'"
              class="icon-xs"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                d="M18.244 2H21l-6.553 7.49L22 22h-6.828l-5.35-6.97L3.71 22H1l7.02-8.03L2 2h6.914l4.84 6.285L18.244 2zm-1.195 18h1.892L7.86 3.938H5.83L17.05 20z"
              />
            </svg>
            <svg
              v-else-if="social.id === 'instagram'"
              class="icon-xs"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"
              />
            </svg>
            <svg
              v-else
              class="icon-xs"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 4-8 4z"
              />
            </svg>
          </a>
        </template>
      </div>
    </div>

    <div v-for="(col, idx) in columns" :key="col.id" class="footer-col">
      <h4 class="footer-heading">{{ col.heading }}</h4>
      <ul
        class="footer-links"
        :class="{ 'footer-links-tight': idx === columns.length - 1 }"
      >
        <li v-for="link in col.links" :key="link.id">
          <NuxtLink
            :to="link.to"
            :target="link.newTab ? '_blank' : undefined"
            :rel="link.newTab ? 'noopener noreferrer' : undefined"
          >{{ link.label }}</NuxtLink>
        </li>
      </ul>

      <template v-if="idx === columns.length - 1">
        <h4 class="footer-heading">{{ newsletterHeading }}</h4>
        <form
          class="footer-email-row"
          :action="`mailto:${newsletterEmail}`"
          method="post"
          enctype="text/plain"
        >
          <input
            type="email"
            name="email"
            placeholder="Email"
            class="footer-email-input"
            required
          />
          <button class="footer-email-btn" type="submit" aria-label="Subscribe">
            &rarr;
          </button>
        </form>
      </template>
    </div>
  </div>
</template>

<style scoped>
.footer-cols {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 32px;
  margin-bottom: 40px;
}
.footer-col {
  min-width: 0;
}

.footer-logo {
  height: 32px;
  object-fit: contain;
  margin-bottom: 24px;
  display: block;
}
.footer-about {
  color: #6b7280;
  font-size: 14px;
  line-height: 1.6;
  margin: 0 0 24px;
  max-width: 380px;
}
.footer-social-row {
  display: flex;
  gap: 12px;
}
.social-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.05);
  color: #9ca3af;
  transition: all 0.2s;
}
.social-icon:hover {
  background: #d34135;
  color: #fff;
}
.icon-xs {
  width: 16px;
  height: 16px;
}

.footer-heading {
  color: #fff;
  font-weight: 700;
  font-size: 14px;
  text-transform: uppercase;
  margin: 0 0 24px;
  letter-spacing: 0.1em;
}
.footer-links {
  list-style: none;
  padding: 0;
  margin: 0 0 8px;
}
.footer-links-tight {
  margin-bottom: 24px;
}
.footer-links li {
  margin-bottom: 16px;
}
.footer-links a {
  color: #6b7280;
  font-size: 14px;
  transition: color 0.2s;
  text-decoration: none;
}
.footer-links a:hover {
  color: #fff;
}

.footer-email-row {
  position: relative;
}
.footer-email-input {
  width: 100%;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 12px 48px 12px 16px;
  font-size: 14px;
  color: #fff;
  outline: none;
  font-family: inherit;
  transition: border-color 0.2s;
  box-sizing: border-box;
}
.footer-email-input:focus {
  border-color: #d34135;
}
.footer-email-input::placeholder {
  color: #6b7280;
}
.footer-email-btn {
  position: absolute;
  right: 8px;
  top: 8px;
  background: #d34135;
  padding: 6px 10px;
  border-radius: 6px;
  border: none;
  color: #fff;
  font-weight: 700;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
}
.footer-email-btn:hover {
  background: #fff;
  color: #d34135;
}

@media (max-width: 991.98px) {
  .footer-cols {
    grid-template-columns: 1fr 1fr;
  }
  .footer-col-brand {
    grid-column: 1 / -1;
  }
}
@media (max-width: 600px) {
  .footer-cols {
    grid-template-columns: 1fr;
  }
}
</style>
