<script setup lang="ts">
// Renderer for the `events-hero` block — the dark masthead + members-priority
// band, ported from the old static /events page. Fixed copy (no fields); the
// standard fields/options/data props are accepted but unused.
defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();
</script>

<template>
  <div class="block-events-hero">
    <section class="hero-dark-section">
      <div class="container-custom container-narrow">
        <div class="events-hero-pad">
          <span class="section-label-sm">Decode Events</span>
          <h1 class="page-hero-title">Where the<br />reporting<br />continues.</h1>
          <div class="hero-row">
            <div class="hero-col">
              <p class="hero-body-text">
                Our reporting does not end on the page. Decode hosts
                conversations where the questions our journalism raises can be
                explored with more voices and more depth — with people affected,
                researchers who study these systems, and readers who want to
                engage directly with the work.
              </p>
            </div>
            <div class="hero-col">
              <p class="hero-body-text">
                We organise member briefings where reporters walk through how an
                investigation was built. Public discussions on AI, misinformation,
                and digital rights. Forums on children's safety online for
                parents, educators, and policymakers. Roundtables with platform
                workers and labour researchers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="member-priority-band">
      <div class="container-custom container-narrow">
        <div class="member-priority-wrapper">
          <p class="member-priority-text">
            Members receive priority invitations before events open to the public
            — including exclusive briefings never listed publicly.
          </p>
          <NuxtLink to="/about" class="btn-member-cta">Become a Member</NuxtLink>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.container-custom {
  width: 100%;
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.container-narrow {
  max-width: 1100px;
  margin: 0 auto;
}
@media (max-width: 768px) {
  .container-custom {
    padding: 0 16px;
  }
}

.hero-dark-section {
  background-color: #121212;
  color: #e5e5e5;
  padding: 60px 0;
}
.events-hero-pad {
  padding: 40px 0;
}
.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d32f2f;
  margin-bottom: 20px;
  display: block;
}
.page-hero-title {
  font-size: clamp(40px, 6vw, 64px);
  font-weight: 700;
  line-height: 1.05;
  color: #f3f0e0;
  margin: 0 0 24px 0;
  letter-spacing: -0.02em;
}
.hero-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 32px;
}
@media (max-width: 768px) {
  .hero-row {
    grid-template-columns: 1fr;
    gap: 20px;
  }
}
.hero-body-text {
  font-size: 16px;
  line-height: 1.7;
  color: #9ca3af;
  margin: 0;
}

.member-priority-band {
  background-color: #1a1a1a;
  border-top: 1px solid rgba(211, 65, 53, 0.3);
  border-bottom: 1px solid rgba(211, 65, 53, 0.3);
  padding: 24px 0;
}
.member-priority-wrapper {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
}
@media (max-width: 768px) {
  .member-priority-wrapper {
    flex-direction: column;
    align-items: flex-start;
  }
}
.member-priority-text {
  font-size: 15px;
  color: #9ca3af;
  line-height: 1.6;
  margin: 0;
}
.btn-member-cta {
  display: inline-block;
  background-color: #d32f2f;
  color: #fff;
  padding: 12px 28px;
  border-radius: 6px;
  font-weight: 600;
  font-size: 15px;
  text-decoration: none;
  transition: background-color 0.2s;
  white-space: nowrap;
}
.btn-member-cta:hover {
  background-color: #b5352a;
  color: #fff;
}
</style>
