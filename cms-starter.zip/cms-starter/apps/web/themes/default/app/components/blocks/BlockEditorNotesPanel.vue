<script setup lang="ts">
import EditorNotesSlider from '~/components/EditorNotesSlider.vue';

// Standalone block: the article-sidebar card wrapping the "From the Editor"
// slider in column layout. Wrapper markup + styles moved verbatim from
// ArticleSidebar.vue (theme engine v1.5 re-blocking); the slider is the
// shared, self-contained EditorNotesSlider. Distinct from the category
// sidebar's editor-notes-column (different card chrome) and the home page's
// editor-notes discovery row.
defineProps<{
  fields: Record<string, unknown>;
  options: Record<string, unknown>;
  data: Record<string, unknown> | null;
}>();
</script>

<template>
  <div class="sidebar-card sidebar-editor">
    <EditorNotesSlider layout="column" />
  </div>
</template>

<style scoped>
.sidebar-card {
  background: #faf7f2;
  border: 1px solid rgba(0, 0, 0, 0.06);
  border-radius: 22px;
  padding: 24px;
  margin-bottom: 12px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
}
.sidebar-editor {
  position: relative;
}
</style>
