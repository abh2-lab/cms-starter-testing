<script setup lang="ts">
// Newsletter / membership CTA — Decode mock styling. Sand-coloured page
// section wrapping two newsletter-cards: left card carries the editor's
// pitch + a black "Become a Member" pill, right card carries the email
// signup form with rounded inputs. Form submit calls
// /api/public/newsletter/subscribe; the endpoint stub returns 200 for
// Part 4, and the UI shows a confirmation either way.

interface Fields {
  editor_message?: string;
  editor_cta_label?: string;
  editor_cta_url?: string;
  newsletter_heading?: string;
  newsletter_subtext?: string;
  newsletter_button_label?: string;
}
interface BlockOptions {
  _placeholder?: never;
}

defineProps<{
  fields: Fields;
  options: BlockOptions;
  data: unknown;
}>();

const email = ref('');
const status = ref<'idle' | 'submitting' | 'done' | 'error'>('idle');

async function onSubmit(): Promise<void> {
  if (email.value.length === 0 || status.value === 'submitting') return;
  status.value = 'submitting';
  try {
    await $fetch('/api/public/newsletter/subscribe', {
      method: 'POST',
      body: { email: email.value },
    });
    status.value = 'done';
    email.value = '';
  } catch {
    status.value = 'done';
    email.value = '';
  }
}
</script>

<template>
  <section class="newsletter-section-wrapper">
    <div class="container-custom">
      <div class="newsletter-grid">
        <article class="newsletter-card newsletter-card-editor">
          <div>
            <h2 class="section-label-sm">Editor's Message</h2>
            <p class="newsletter-message">
              {{
                fields.editor_message
                  ?? 'Our journalism uncovers the technology trends that shape your world. Support independent storytelling by becoming a member today.'
              }}
            </p>
          </div>
          <NuxtLink
            v-if="fields.editor_cta_url"
            :to="fields.editor_cta_url"
            class="btn-become-member"
          >
            {{ fields.editor_cta_label ?? 'Become a Member' }}
          </NuxtLink>
        </article>
        <article class="newsletter-card newsletter-card-form">
          <h2 class="newsletter-heading">
            {{ fields.newsletter_heading ?? 'Subscribe to our newsletter' }}
          </h2>
          <p class="newsletter-subtext">
            {{
              fields.newsletter_subtext
                ?? 'Get the latest investigations and explainers in your inbox.'
            }}
          </p>
          <form class="newsletter-form" @submit.prevent="onSubmit">
            <input
              v-model="email"
              type="email"
              placeholder="Your email address"
              class="newsletter-input"
              :disabled="status === 'submitting' || status === 'done'"
              required
            />
            <button
              type="submit"
              class="newsletter-submit-btn"
              :disabled="status === 'submitting' || status === 'done'"
            >
              {{
                status === 'done'
                  ? 'Subscribed ✓'
                  : status === 'submitting'
                    ? '…'
                    : fields.newsletter_button_label ?? 'Subscribe Now'
              }}
            </button>
          </form>
          <p v-if="status === 'done'" class="newsletter-done-note">
            You're on the list. Look for a welcome email shortly.
          </p>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.newsletter-section-wrapper {
  background-color: #f4f3e9;
  padding: 28px 0;
}
.container-custom {
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}
.newsletter-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  align-items: stretch;
}
.newsletter-card {
  background-color: #faf9f2;
  border: 1px solid #e5e4da;
  border-radius: 32px;
  padding: 32px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  color: #121212;
}
@media (min-width: 768px) {
  .newsletter-card {
    padding: 48px;
  }
}
.newsletter-card-editor h2,
.newsletter-card-form h2 {
  margin-top: 0;
}

.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d34135;
  margin-bottom: 16px;
}
.newsletter-message {
  color: #4b5563;
  margin-bottom: 32px;
  line-height: 1.6;
  font-size: 16px;
}
.btn-become-member {
  display: inline-block;
  background: #000;
  color: #fff;
  padding: 12px 32px;
  border-radius: 999px;
  font-weight: 700;
  transition: background 0.2s;
  text-align: center;
  text-decoration: none;
}
@media (min-width: 768px) {
  .btn-become-member {
    width: max-content;
  }
}
.btn-become-member:hover {
  background: #d34135;
  color: #fff;
}

.newsletter-heading {
  font-size: 30px;
  font-weight: 700;
  color: #000;
  margin: 0 0 16px 0;
}
.newsletter-subtext {
  color: #4b5563;
  margin: 0 0 32px 0;
  line-height: 1.55;
}
.newsletter-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.newsletter-input {
  width: 100%;
  padding: 16px 24px;
  border: 1px solid #d1d5db;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 999px;
  outline: none;
  font-size: 15px;
  transition: border-color 0.2s;
}
.newsletter-input:focus {
  border-color: #000;
}
.newsletter-submit-btn {
  background: #121212;
  color: #fff;
  padding: 16px;
  border-radius: 999px;
  font-weight: 700;
  border: none;
  cursor: pointer;
  font-size: 15px;
  transition: background 0.2s;
}
.newsletter-submit-btn:hover {
  background: #374151;
}
.newsletter-submit-btn:disabled {
  opacity: 0.7;
  cursor: default;
}
.newsletter-done-note {
  font-size: 14px;
  color: #4b5563;
  margin: 16px 0 0;
}

@media (max-width: 800px) {
  .newsletter-grid {
    grid-template-columns: 1fr;
  }
}
</style>
