<script setup lang="ts">
import EditorNotesSlider from '~/components/EditorNotesSlider.vue';

// EditorNotes — "From the Editor" promo strip on the home page. Wraps the
// shared EditorNotesSlider in a discovery-card so it composes into the
// discovery-row with BlockFeatureStories on desktop. The slide copy lives in
// EditorNotesSlider (single source of truth — the category sidebar reuses
// the same slider with layout="column"). The editor-controlled surface is
// just the optional kicker `title`.

interface Fields {
  title?: string;
}

const props = defineProps<{
  fields: Fields;
  options: Record<string, never>;
  data: null;
}>();

void props;
</script>

<template>
  <section class="block-editor-notes">
    <div class="container-custom">
      <div class="discovery-row">
        <div class="discovery-card note-slider-card">
          <div>
            <h2 class="section-label-sm">{{ fields.title ?? 'From the Editor' }}</h2>
            <EditorNotesSlider layout="row" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.block-editor-notes {
  padding: 0 0 32px;
  background: transparent;
}
.container-custom {
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}

.discovery-row {
  display: flex;
  gap: 2.5rem;
  align-items: stretch;
  /* Negative top margin pulls the card visually into the row above when a
     feature-stories block sits directly before this on the home page,
     reconstructing the side-by-side discovery-row from the Decode mock. The
     value matches BlockFeatureStories' -30px so they line up. Editors can
     reorder the blocks; if editor-notes lands somewhere else, the layout
     still flows naturally as a standalone discovery row. */
  margin-top: -30px;
}
.discovery-card {
  background: #faf9f2;
  border: 1px solid #e5e4da;
  border-radius: 12px;
  padding: 1.5rem 2rem;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05);
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  color: #121212;
}

.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d34135;
  margin-bottom: 20px;
}

@media (max-width: 900px) {
  .discovery-row {
    flex-direction: column;
    gap: 1.5rem;
    /* On mobile each block stacks normally so the negative-top hack from
       above doesn't drag the card under the previous block's content. */
    margin-top: 0;
  }
}
</style>
