<script setup lang="ts">
import type { StoryListItem } from '~/composables/useCmsFetch';
import { primaryCategory, formatPublishDateShort } from '~/composables/useStatusPill';
import EditorNotesSlider from '~/components/EditorNotesSlider.vue';
import { articleUrl, authorUrl } from '~/utils/urls';

// Feature stories + From the Editor — the full discovery-row from the
// Decode mock. Two cards inside one flex row: a story-slider on the
// left (fade-between-slides for the latest N stories) and the design-
// locked editor-notes promo slider on the right.
//
// The two cards have to share a single discovery-row container to sit
// side-by-side on desktop. Page-block rendering happens block-by-block
// with no way for the page layout to inspect adjacency, so the cleanest
// way to keep them in one row is to render both inside this block.
// BlockEditorNotes.vue + packages/blocks/.../editor-notes.ts still ship
// as a standalone block so a publisher who wants the promo strip
// alone (no story slider) can drop it onto a different page.

interface Fields {
  title?: string;
  eyebrow?: string;
}
interface BlockOptions {
  content_type?: string;
  category?: string;
  count?: number;
}
interface Data {
  items: StoryListItem[];
}

const props = defineProps<{
  fields: Fields;
  options: BlockOptions;
  data: Data | null;
}>();

const items = computed<StoryListItem[]>(() => props.data?.items ?? []);
// Show one slide at a time, like the mock — we render the first as active
// and the others as hidden DOM so the dots-count matches what's available.
const activeIndex = ref(0);

function setActive(i: number): void {
  if (i >= 0 && i < items.value.length) activeIndex.value = i;
}
function prev(): void {
  if (items.value.length === 0) return;
  activeIndex.value =
    (activeIndex.value - 1 + items.value.length) % items.value.length;
}
function next(): void {
  if (items.value.length === 0) return;
  activeIndex.value = (activeIndex.value + 1) % items.value.length;
}
</script>

<template>
  <section v-if="items.length > 0" class="block-feature-stories">
    <div class="container-custom">
      <div class="discovery-row">
        <div class="discovery-card story-slider-card">
          <div>
            <h2 v-if="fields.title" class="section-label-sm">
              {{ fields.title }}
            </h2>
            <div class="story-slider-content">
              <div
                v-for="(story, i) in items"
                :key="story.id"
                class="story-slide"
                :class="{ active: i === activeIndex }"
              >
                <NuxtLink :to="articleUrl(story.slug, story.primaryCategorySlug)">
                  <img
                    v-if="story.heroImageUrl"
                    loading="lazy"
                    decoding="async"
                    :src="story.heroImageUrl"
                    class="feature-img grayscale-img"
                    :alt="story.title"
                  />
                  <div
                    v-else
                    class="feature-img feature-img-placeholder"
                  ></div>
                </NuxtLink>
                <div>
                  <NuxtLink :to="articleUrl(story.slug, story.primaryCategorySlug)" class="story-slide-title-link">
                    <h3 class="story-slide-title" >{{ story.title }}</h3>
                  </NuxtLink>
                  <span class="story-slide-meta">
                    <a
                      v-if="primaryCategory(story.taxonomy)"
                      href="#"
                      class="lbl-feature meta-link"
                      @click.prevent
                    >
                      Feature
                    </a>
                    <!-- Each downstream segment owns its OWN leading
                         separator (` · `) so an absent author or date no
                         longer leaves a dangling `· ` after the category
                         label. Old shape was "Feature · Labour · " when
                         the row had no byline; now it's just
                         "Feature · Labour". -->
                    <template v-if="primaryCategory(story.taxonomy)">
                      &middot; {{ primaryCategory(story.taxonomy)!.termName }}
                    </template>
                    <template v-if="story.authors">
                      &middot; By
                      <template
                        v-for="(a, ai) in story.authors"
                        :key="a.slug ?? ai"
                      >
                        <template
                          v-if="ai > 0 && ai === story.authors.length - 1"
                        >
                          &amp;
                        </template>
                        <template v-else-if="ai > 0">, </template>
                        <NuxtLink
                          v-if="a.slug"
                          :to="authorUrl(a.slug)"
                          class="meta-link"
                        >
                          {{ a.displayName }}
                        </NuxtLink>
                        <span v-else>{{ a.displayName }}</span>
                      </template>
                    </template>
                    <template v-if="story.publishedAt">
                      &middot; {{ formatPublishDateShort(story.publishedAt) }}
                    </template>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="story-slider-footer">
            <div class="dots-row">
              <button
                v-for="(_, i) in items"
                :key="i"
                type="button"
                class="dot"
                :class="{ active: i === activeIndex }"
                :aria-label="`Slide ${i + 1}`"
                @click="setActive(i)"
              />
            </div>
            <div class="arrows-row">
              <button
                type="button"
                class="arrow-nav"
                aria-label="Previous slide"
                @click="prev"
              >
                &#8592;
              </button>
              <button
                type="button"
                class="arrow-nav"
                aria-label="Next slide"
                @click="next"
              >
                &#8594;
              </button>
            </div>
          </div>
        </div>

        <!-- From the Editor — note-slider card sharing the same row. The
             slider state + the 4 design-locked slides live in the leaf
             EditorNotesSlider so the standalone BlockEditorNotes (which a
             publisher can drop on a different page) reuses the same code.

             No "From the Editor" eyebrow here — the Decode mock's right
             card uses the slide's own heading (HELP DECODE / NEWSLETTER /
             ...) as the visual anchor. A redundant section label above it
             read as a CMS dev artifact rather than the publication's
             editorial chrome. The standalone BlockEditorNotes (placed
             elsewhere) still ships its own context where it needs one. -->
        <div class="discovery-card note-slider-card">
          <div>
            <EditorNotesSlider layout="row" />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.block-feature-stories {
  padding: 24px 0 0;
  background: transparent;
}
.container-custom {
  max-width: 1440px;
  margin: 0 auto;
  padding: 0 40px;
}

.discovery-row {
  display: flex;
  gap: 2.5rem;
  align-items: stretch;
  margin-top: -30px;
}
.discovery-card {
  background: #faf9f2;
  border: 1px solid #e5e4da;
  border-radius: 12px;
  padding: 1.5rem 2rem;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05);
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  color: #121212;
}
.story-slider-card {
  flex: 1.5;
}

.section-label-sm {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.3em;
  color: #d34135;
  margin-bottom: 20px;
}

.story-slider-content {
  position: relative;
}
.story-slide {
  display: none;
  flex-direction: row;
  align-items: flex-start;
  gap: 1.5rem;
}
.story-slide.active {
  display: flex;
  animation: fadeIn 0.4s ease;
}
.story-slide > a {
  flex: 0 0 260px;
}
.story-slide > div {
  flex: 1;
  min-width: 0;
}
.feature-img {
  width: 100%;
  aspect-ratio: 1280 / 768;
  height: auto;
  object-fit: cover;
  border-radius: 6px;
  display: block;
}
.feature-img-placeholder {
  background: linear-gradient(135deg, #e5e4da, #cccccc);
}
.grayscale-img {
  filter: grayscale(100%);
  transition: filter 0.3s;
}
.grayscale-img:hover {
  filter: grayscale(0%);
}
.story-slide-title {
  font-size: 20px;
  font-weight: 700;
  color: #1f2937;
  line-height: 1.3;
  margin: 0 0 8px 0;
  transition: color 0.2s;
}

.story-slide-title-link {
  text-decoration: none;
}

.story-slide-title:hover {
  color: #d34135;
}
.story-slide-meta {
  font-size: 11px;
  color: #6b7280;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 0.1em;
}

/* "Feature" kicker — matches the Decode brand red. The original
   #3b82f6 (blue) was a placeholder carried over from a generic mock; the
   published Decode mockup uses the same red as the other section tags. */
.lbl-feature {
  color: #d34135 !important;
}
.meta-link {
  color: inherit;
  text-decoration: none;
  transition: text-decoration 0.2s;
}
.meta-link:hover {
  text-decoration: underline;
}

.story-slider-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
}
.dots-row {
  display: flex;
  gap: 0.5rem;
}
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #ccc;
  cursor: pointer;
  transition: 0.3s;
  border: none;
  padding: 0;
}
.dot.active {
  background: #d34135;
  transform: scale(1.3);
}
.arrows-row {
  display: flex;
  gap: 1rem;
}
.arrow-nav {
  font-size: 24px;
  color: #121212;
  cursor: pointer;
  transition: 0.3s;
  font-weight: bold;
  user-select: none;
  background: transparent;
  border: none;
  padding: 0;
}
.arrow-nav:hover {
  color: #d34135;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@media (max-width: 900px) {
  .discovery-row {
    flex-direction: column;
    gap: 1.5rem;
  }
  .story-slide {
    flex-direction: column;
  }
  .story-slide > a {
    flex: 0 0 auto;
    width: 100%;
  }
}
</style>
