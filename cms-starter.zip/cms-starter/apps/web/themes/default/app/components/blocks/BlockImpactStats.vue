<script setup lang="ts">
// Impact Stats block — purely data-driven from `fields.stats`. The API-side
// loader passes the cleaned stats array through `data.stats`. Rendered
// inline (no separate ImpactStats component); the block is the renderer.

interface Stat {
  label: string;
  value: string;
}
interface Fields {
  eyebrow?: string;
  title?: string;
  stats?: Stat[];
}
interface Data {
  title: string;
  eyebrow: string;
  stats: Stat[];
}

const props = defineProps<{
  fields: Fields;
  options: Record<string, unknown>;
  data: Data | null;
}>();

// Prefer the loader-resolved data (the loader cleans malformed entries),
// fall back to the raw fields so a dev who skips the loader path still
// gets something to look at.
const stats = computed<Stat[]>(() =>
  props.data?.stats ??
  (props.fields.stats ?? []).filter(
    (s): s is Stat =>
      !!s && typeof s.label === 'string' && typeof s.value === 'string',
  ),
);
const title = computed(() => props.data?.title ?? props.fields.title ?? '');
const eyebrow = computed(
  () => props.data?.eyebrow ?? props.fields.eyebrow ?? '',
);
</script>

<template>
  <section v-if="stats.length > 0" class="block-impact-stats container">
    <p v-if="eyebrow" class="eyebrow">{{ eyebrow }}</p>
    <h2 v-if="title">{{ title }}</h2>
    <ul class="stats-grid">
      <li v-for="s in stats" :key="s.label" class="stat">
        <div class="value">{{ s.value }}</div>
        <div class="label">{{ s.label }}</div>
      </li>
    </ul>
  </section>
  <div v-else class="empty container">
    <p>Impact Stats block: add at least one stat to display.</p>
  </div>
</template>

<style scoped>
.block-impact-stats {
  padding: 24px 20px;
}
.eyebrow {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--muted);
  margin-bottom: 6px;
}
.block-impact-stats h2 {
  font-size: 22px;
  font-weight: 700;
  margin-bottom: 16px;
}
.stats-grid {
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px;
}
.stat {
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 12px 14px;
  background: var(--surface);
}
.stat .value {
  font-size: 22px;
  font-weight: 700;
}
.stat .label {
  font-size: 13px;
  color: var(--muted);
}
.empty {
  padding: 16px 20px;
  border: 1px dashed var(--border);
  border-radius: var(--radius);
  color: var(--muted);
  font-size: 14px;
}
</style>
