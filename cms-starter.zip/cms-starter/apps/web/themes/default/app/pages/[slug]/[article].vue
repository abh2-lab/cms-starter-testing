<script setup lang="ts">
import ArticleView from '~/components/ArticleView.vue';

// Canonical article URL — /<primary-category-slug>/<article-slug>.
// Both segments are dynamic; Nuxt's router prioritises static segments
// over dynamic so /author/<slug>, /authors, /uncategorized/<slug>,
// /preview/block/<key> and /stories all win this match against their
// own routes before this two-segment fallback fires.
//
// The category segment is presentational — the article fetch keys off
// the article slug alone. The breadcrumb anchor uses the response's
// own primaryCategorySlug, so a URL mismatch (rare; the canonical URL
// is server-generated) renders cleanly without a redirect.
const route = useRoute();
const articleSlug = computed(() => {
  const raw = route.params['article'];
  return typeof raw === 'string' ? raw : '';
});
</script>

<template>
  <ArticleView :slug="articleSlug" />
</template>
