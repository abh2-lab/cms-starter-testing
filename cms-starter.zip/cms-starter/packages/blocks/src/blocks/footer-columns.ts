import type { Block } from '../types.js';

// footer-columns — a standalone block: the footer's main grid (brand column
// with logo + about blurb + social icons, the CMS-menu link columns, and the
// newsletter signup welded into the last column). ONE block for the whole
// grid on purpose: the brand column and the link columns are siblings inside
// one CSS grid, and the newsletter form renders INSIDE the last link
// column's iteration — sibling blocks could not reproduce that DOM without
// restructuring it (a pixel-parity violation).
//
// The renderer self-fetches the menu named by `menu_slug` (plus the site
// settings logo) exactly as the hand-built SiteFooter did. All previously
// hardcoded copy (about blurb, social URLs, newsletter strings) becomes
// editable fields.

interface FooterColumnsFields {
  about_text?: string;
  twitter_url?: string;
  instagram_url?: string;
  youtube_url?: string;
  newsletter_heading?: string;
  newsletter_email?: string;
}

interface FooterColumnsOptions {
  menu_slug?: string;
}

export const footerColumns: Block<FooterColumnsFields, FooterColumnsOptions> = {
  meta: {
    key: 'footer-columns',
    label: 'Footer Columns',
    category: 'site',
    description:
      'The footer grid: brand column (logo, blurb, social icons), menu-driven link columns, and the newsletter signup.',
    icon: 'grid',
    fields: [
      {
        key: 'about_text',
        label: 'About text',
        type: 'long_text',
        default:
          'Decode is an independent investigative publication examining how technology shapes power, labour, childhood, identity, and truth in India. Reader-supported. Editorially independent.',
      },
      {
        key: 'twitter_url',
        label: 'Twitter / X URL',
        type: 'url',
        default: '#',
      },
      {
        key: 'instagram_url',
        label: 'Instagram URL',
        type: 'url',
        default: '#',
      },
      {
        key: 'youtube_url',
        label: 'YouTube URL',
        type: 'url',
        default: '#',
      },
      {
        key: 'newsletter_heading',
        label: 'Newsletter heading',
        type: 'short_text',
        default: 'Stay Updated',
      },
      {
        key: 'newsletter_email',
        label: 'Newsletter signup email',
        type: 'short_text',
        default: 'subscribe@decode.in',
        helpText:
          'The mailto: target the signup form posts to until a real list provider is wired up.',
      },
    ],
    options: [
      {
        key: 'menu_slug',
        label: 'Menu',
        type: 'short_text',
        default: 'footer-nav',
        helpText:
          'Slug of the CMS menu whose top-level items become column headings and children become links. Falls back to the built-in columns when absent.',
      },
    ],
  },
  load() {
    return Promise.resolve(null);
  },
};
