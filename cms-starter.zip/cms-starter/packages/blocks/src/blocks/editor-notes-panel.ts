import type { Block } from '../types.js';

// editor-notes-panel — a standalone block: the article-sidebar card wrapping
// the "From the Editor" promo slider in column layout. The slider is
// self-contained (design-locked copy, own state); this block exists so the
// panel can be reordered/removed in the sidebar part. Distinct from the
// category sidebar's `editor-notes-column` (different card background and
// border treatment) and the home page's `editor-notes` discovery row.

export const editorNotesPanel: Block = {
  meta: {
    key: 'editor-notes-panel',
    label: 'Editor Notes (panel)',
    category: 'article',
    description:
      'Sidebar card with the "From the Editor" slider in column layout.',
    icon: 'megaphone',
    fields: [],
    options: [],
  },
  load() {
    return Promise.resolve(null);
  },
};
