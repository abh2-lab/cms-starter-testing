import type { Block } from '../types.js';

// events-cta — the dark "Priority access to every event" card at the bottom of
// the /events page. Fixed chrome (hardcoded copy in the renderer); no fields,
// no-op loader. A block so the dynamic events page can place it.
export const eventsCta: Block = {
  meta: {
    key: 'events-cta',
    label: 'Events CTA',
    category: 'events',
    description: 'Dark members-priority call-to-action card (fixed copy).',
    icon: 'star',
    fields: [],
    options: [],
  },
  load() {
    return Promise.resolve(null);
  },
};
