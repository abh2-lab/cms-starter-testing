import type { Block } from '../types.js';

// ContactForm — the /contact page body (theme engine v2 Phase 4). The component
// POSTs to /api/public/submissions itself (a side-effect the loader must never
// do), so server-side load() is a no-op; the editable copy is in fields and the
// target content type in `content_type_slug`. The chosen content type must have
// submissionAccess: 'public' configured in admin.

interface ContactFormFields {
  heading?: string;
  lede?: string;
  button_label?: string;
  success_message?: string;
}
interface ContactFormOptions {
  content_type_slug?: string;
}

export const contactForm: Block<ContactFormFields, ContactFormOptions> = {
  meta: {
    key: 'contact-form',
    label: 'Contact Form',
    category: 'forms',
    description:
      'A name/email/subject/message form that saves a public submission as a draft for review.',
    icon: 'envelope',
    fields: [
      {
        key: 'heading',
        label: 'Heading',
        type: 'short_text',
        default: 'Contact',
      },
      {
        key: 'lede',
        label: 'Intro text',
        type: 'long_text',
        default:
          'Send us a message. Submissions are saved as drafts in admin for review.',
      },
      {
        key: 'button_label',
        label: 'Submit button label',
        type: 'short_text',
        default: 'Send',
      },
      {
        key: 'success_message',
        label: 'Success message',
        type: 'short_text',
        default: 'Thanks — your message was received.',
      },
    ],
    options: [
      {
        key: 'content_type_slug',
        label: 'Submission content type',
        type: 'content_type_slug',
        default: 'article',
        helpText:
          'Submissions are saved as drafts of this content type (it must allow public submissions).',
      },
    ],
  },
  load: () => Promise.resolve(null),
};
