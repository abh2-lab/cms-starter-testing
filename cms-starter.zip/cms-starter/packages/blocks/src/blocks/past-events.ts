import type { Block } from '../types.js';

// past-events — the "Past Events" grid from the (now block-based) /events page.
// A self-contained STANDALONE block: its event list is hardcoded in the loader
// (like editor-notes' slides) and returned as `data`, so the renderer stays a
// pure { fields, options, data } consumer. The events link out to external
// recaps; a card with no recap_url renders its title as static text.
//
// (Hardcoded on purpose for now — to make these CMS-editable later you'd model
// an "Event" content type + fetch them in load(); the renderer wouldn't change.)

interface PastEvent {
  type_label: string; // pill above the image, e.g. "Panel Discussion"
  type_variant: 'investigation' | 'forum'; // pill colour (red / blue)
  image: string;
  overlay_label: string; // label on the image gradient, e.g. "AI & Elections"
  accent_light?: boolean; // overlay accent line: light vs red
  title: string;
  description: string;
  recap_url?: string; // external recap link; omitted → static title
}

interface PastEventsFields {
  eyebrow?: string;
  title?: string;
}

const EVENTS: PastEvent[] = [
  {
    type_label: 'Panel Discussion',
    type_variant: 'investigation',
    image:
      'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1280&h=768&q=80',
    overlay_label: 'Cybercrime & Law Enforcement',
    title: 'Fighting Cybercrime: From The Frontlines',
    description: 'With Muktesh Chander, Nirali Bhatia, Khemendra Pal Singh.',
    recap_url:
      'https://www.boomlive.in/decode/decode-event-recap-its-easier-to-investigate-a-murder-case-than-cybercrime-in-india-27246',
  },
  {
    type_label: 'Panel Discussion',
    type_variant: 'investigation',
    image:
      'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=1280&h=768&q=80',
    overlay_label: 'AI & Elections',
    title: 'Decoding Deepfakes & Elections',
    description:
      'With Mayank Vatsa, Karen Rebelo, Kanksshi Agarwal, Vibodh Parthasarathi, Sanhita Chauriha.',
    recap_url:
      'https://www.boomlive.in/decode/deepfake-tech-isnt-bad-intent-is-decode-panel-on-deepfakes-elections-24013',
  },
  {
    type_label: 'Forum & Discussion',
    type_variant: 'forum',
    accent_light: true,
    image:
      'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1280&h=768&q=80',
    overlay_label: 'Technology & Media',
    title: 'AI x Journalism',
    description:
      'A gathering of journalists, technologists, and media practitioners — with demos and discussions on how AI is changing the practice and ethics of reporting.',
  },
  {
    type_label: 'Online Discussion',
    type_variant: 'forum',
    accent_light: true,
    image:
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1280&h=768&q=80',
    overlay_label: 'Children & Digital Safety',
    title: 'Is Social Media Ban For Children The Answer?',
    description:
      'An online discussion bringing together experts, teenagers, and journalists to examine the case for and against banning children from social media platforms.',
  },
];

export const pastEvents: Block<PastEventsFields, Record<string, unknown>> = {
  meta: {
    key: 'past-events',
    label: 'Past Events',
    category: 'events',
    description: 'A grid of past Decode events (links out to recaps).',
    icon: 'calendar',
    fields: [
      {
        key: 'eyebrow',
        label: 'Eyebrow',
        type: 'short_text',
        default: 'From the archive',
      },
      {
        key: 'title',
        label: 'Section title',
        type: 'short_text',
        default: 'Past Events',
      },
    ],
    options: [],
  },
  load() {
    return Promise.resolve({ events: EVENTS });
  },
};
