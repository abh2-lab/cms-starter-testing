import type { Block } from '../types.js';

// HeroFeatured — a richer masthead than the plain Hero block. Same single-
// story-by-slug data shape, plus three editor-supplied copy fields:
//   - kicker_override: overrides the story's own kicker for the masthead
//   - editorial_note: short "Why read this" callout shown under the headline
//   - date_label:    two-line date badge ("20 Nov" / "2025 //") in the corner
// of the hero image. Pure presentational fields — the loader returns the
// same `{story}` shape as Hero so the renderer can fall back gracefully.

interface HeroFeaturedFields {
  kicker_override?: string;
  editorial_note?: string;
  date_label?: string;
}
interface HeroFeaturedOptions {
  content_type?: string;
  slug?: string;
}

export const heroFeatured: Block<HeroFeaturedFields, HeroFeaturedOptions> = {
  meta: {
    key: 'hero-featured',
    label: 'Hero — featured story',
    category: 'lead',
    description:
      'Large masthead with editorial-note callout, rotating "Read now" badge, and date corner tag.',
    icon: 'star',
    fields: [
      {
        key: 'kicker_override',
        label: 'Kicker override',
        type: 'short_text',
        helpText:
          'Optional. Overrides the story\'s own kicker for this masthead only.',
      },
      {
        key: 'editorial_note',
        label: 'Editorial note',
        type: 'long_text',
        helpText:
          '"Why read this" callout shown under the headline. ~30 words.',
      },
      {
        key: 'date_label',
        label: 'Date badge',
        type: 'short_text',
        helpText:
          'Two-line yellow corner badge — usually a publish date like "20 Nov / 2025".',
      },
    ],
    options: [
      {
        key: 'content_type',
        label: 'Content type',
        type: 'content_type_slug',
        required: true,
        default: 'article',
      },
      {
        key: 'slug',
        label: 'Story slug',
        type: 'content_slug',
        required: true,
        helpText: 'Slug of the featured story.',
      },
    ],
  },
  async load(ctx, { options }) {
    const typeSlug = options.content_type ?? 'article';
    const storySlug = options.slug ?? '';
    if (!storySlug) return { story: null };
    const story = await ctx.fetchContent(typeSlug, storySlug);
    return { story };
  },
};
