import type { Block } from '../types.js';

// events-hero — the dark masthead + "members priority" band at the top of the
// /events page. Fixed editorial chrome (like editor-notes): the copy is
// hardcoded in the renderer, so this block has no editable fields/options and a
// no-op loader. It exists as a block purely so the (now dynamic) events page can
// place it in its block list.
export const eventsHero: Block = {
  meta: {
    key: 'events-hero',
    label: 'Events Hero',
    category: 'events',
    description: 'Dark events masthead + members-priority band (fixed copy).',
    icon: 'megaphone',
    fields: [],
    options: [],
  },
  load() {
    return Promise.resolve(null);
  },
};
