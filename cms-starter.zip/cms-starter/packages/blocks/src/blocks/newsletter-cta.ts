import type { Block } from '../types.js';

// NewsletterCta — split editorial-message / newsletter-signup section,
// modelled on the Decode home's "Editor's Message + Decode with Adrija"
// row. Pure copy block — no DB fetch. The signup form submit is wired
// to `/api/public/newsletter/subscribe` by the renderer, which 200s as
// a no-op until the worker side ships (Part 5+).

interface NewsletterCtaFields {
  editor_message?: string;
  editor_cta_label?: string;
  editor_cta_url?: string;
  newsletter_heading?: string;
  newsletter_subtext?: string;
  newsletter_button_label?: string;
}
interface NewsletterCtaOptions {
  _placeholder?: never;
}

export const newsletterCta: Block<NewsletterCtaFields, NewsletterCtaOptions> = {
  meta: {
    key: 'newsletter-cta',
    label: 'Newsletter / membership CTA',
    category: 'cta',
    description:
      'Split section: left is an editorial-message + CTA button, right is a newsletter signup form.',
    icon: 'envelope',
    fields: [
      {
        key: 'editor_message',
        label: 'Editor\'s message',
        type: 'long_text',
        default:
          'Our journalism uncovers the technology trends that shape your world. Support independent storytelling by becoming a member today.',
      },
      {
        key: 'editor_cta_label',
        label: 'Editor CTA — button label',
        type: 'short_text',
        default: 'Become a Member',
      },
      {
        key: 'editor_cta_url',
        label: 'Editor CTA — link',
        type: 'url',
        // Default points at /about until a publisher ships a dedicated
        // membership page. /membership reliably 404s on a fresh install
        // so /about is the safer fallback for new pages built from this
        // block. Editors override per-page from the admin.
        default: '/about',
      },
      {
        key: 'newsletter_heading',
        label: 'Newsletter heading',
        type: 'short_text',
        default: 'Subscribe to our newsletter',
      },
      {
        key: 'newsletter_subtext',
        label: 'Newsletter subtext',
        type: 'short_text',
        default:
          'Get the latest investigations and explainers in your inbox.',
      },
      {
        key: 'newsletter_button_label',
        label: 'Newsletter button label',
        type: 'short_text',
        default: 'Subscribe Now',
      },
    ],
    options: [],
  },
  // Pure copy block — nothing to fetch.
  load: () => Promise.resolve(null),
};
