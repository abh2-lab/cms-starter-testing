import type { Block } from '../types.js';

// CategoryStrip — horizontal scroll of category cards, each with an icon
// and a link to /category/<slug>. Icons are inline SVGs keyed by the slug
// on the render side (BlockCategoryStrip.vue maps known Decode category
// slugs to specific SVG glyphs; unknown slugs fall back to a generic
// folder icon). The editor picks which categories to show via the kv_list
// — `label` is the display name, `value` is the category slug.

interface CategoryStripFields {
  title?: string;
  // [{label: "Young Minds", value: "young-minds"}, ...]
  items?: { label: string; value: string }[];
}
interface CategoryStripOptions {
  // intentionally empty — this block is data-pure, no DB fetch
  _placeholder?: never;
}

export const categoryStrip: Block<CategoryStripFields, CategoryStripOptions> = {
  meta: {
    key: 'category-strip',
    label: 'Category strip',
    category: 'navigation',
    description:
      'Horizontal scroll of category cards with icons. Each card links to /category/<slug>.',
    icon: 'grid',
    fields: [
      {
        key: 'title',
        label: 'Section title',
        type: 'short_text',
        default: 'Read by theme',
      },
      {
        key: 'items',
        label: 'Categories',
        type: 'kv_list',
        helpText:
          'Each row: label = display name, value = category slug. Order = display order.',
      },
    ],
    options: [],
  },
  // No DB fetch — the kv_list is the data. Just pass it through (and
  // normalise so the renderer can trust the shape).
  load: (_ctx, { fields }) => {
    const raw = Array.isArray(fields.items) ? fields.items : [];
    const items = raw
      .filter(
        (r): r is { label: string; value: string } =>
          r !== null &&
          typeof r === 'object' &&
          typeof (r as { label?: unknown }).label === 'string' &&
          typeof (r as { value?: unknown }).value === 'string',
      )
      .map((r) => ({ label: r.label, slug: r.value }));
    return Promise.resolve({ items });
  },
};
