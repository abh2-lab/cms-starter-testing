import type { Block } from '../types.js';

// EditorNotes — the "From the Editor" promo strip lifted out of the original
// monolithic FeatureStories block. Four hardcoded slides that promote the
// publisher's membership, tip line, mission and reader-support pages.
//
// Design-locked by intent (philosophy: developer-first, design-locked). The
// slide copy lives in the matching Vue component, not in editor-controlled
// fields, because:
//   * the four-slide structure mirrors the Decode mockup verbatim and
//     varying it would break the visual mapping to that mock
//   * a second publisher will want their own copy; that's a separate
//     publisher-specific Vue component, not editor-configurable fields here
//
// Editors can still: hide the block, reorder it relative to other blocks,
// edit the optional `title` field that drives the kicker. They cannot edit
// slide content or introduce new slides.
//
// Loader returns null — this block has no remote data dependencies. Kept as a
// distinct registry entry (rather than baked into FeatureStories) so a page
// can include only the story slider, or only the editor notes, or both, by
// dropping the matching block in the page composer.

interface EditorNotesFields {
  title?: string;
}
// Reserved for future "linked content type" or "promo target" toggles; empty
// for now keeps the block surface honest about what's configurable. Match
// the placeholder shape used by category-strip's options so the registry's
// Block<Record<string, unknown>> bound is satisfied.
interface EditorNotesOptions {
  _placeholder?: never;
}

export const editorNotes: Block<EditorNotesFields, EditorNotesOptions> = {
  meta: {
    key: 'editor-notes',
    label: 'Editor notes',
    category: 'promo',
    description:
      'The "From the Editor" promo strip — four hardcoded slides linking to membership, tip line, mission, and reader-support pages.',
    icon: 'megaphone',
    fields: [
      {
        key: 'title',
        label: 'Section title',
        type: 'short_text',
        default: 'From the Editor',
      },
    ],
    options: [],
  },
  load: () => Promise.resolve(null),
};
