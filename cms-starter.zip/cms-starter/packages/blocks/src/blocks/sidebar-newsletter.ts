import type { Block } from '../types.js';

// sidebar-newsletter — a standalone block: the compact newsletter CTA card
// from the article's right rail. All previously hardcoded copy becomes
// fields. Distinct from the home page's full-width `newsletter-cta` section
// block — different markup, different card scale.

interface SidebarNewsletterFields {
  label?: string;
  title?: string;
  text?: string;
  button_label?: string;
  signup_email?: string;
  note?: string;
}

export const sidebarNewsletter: Block<
  SidebarNewsletterFields,
  Record<string, unknown>
> = {
  meta: {
    key: 'sidebar-newsletter',
    label: 'Sidebar Newsletter',
    category: 'article',
    description:
      'Compact newsletter signup card for side columns (label, title, blurb, email form).',
    icon: 'envelope',
    fields: [
      {
        key: 'label',
        label: 'Label',
        type: 'short_text',
        default: 'Newsletter',
      },
      {
        key: 'title',
        label: 'Title',
        type: 'short_text',
        default: 'Decode in Your Inbox',
      },
      {
        key: 'text',
        label: 'Text',
        type: 'long_text',
        default:
          'Investigations, explainers, and occasional notes from our reporters — sent when the work warrants it. Free.',
      },
      {
        key: 'button_label',
        label: 'Button label',
        type: 'short_text',
        default: 'Subscribe',
      },
      {
        key: 'signup_email',
        label: 'Signup email',
        type: 'short_text',
        default: 'subscribe@decode.in',
        helpText:
          'The mailto: target the form posts to until a real list provider is wired up.',
      },
      {
        key: 'note',
        label: 'Note',
        type: 'short_text',
        default: 'No spam. Unsubscribe anytime.',
      },
    ],
    options: [],
  },
  load() {
    return Promise.resolve(null);
  },
};
