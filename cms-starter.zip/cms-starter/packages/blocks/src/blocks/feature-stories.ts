import type { Block } from '../types.js';

// FeatureStories — a small, visually distinct grid of the latest N stories
// from a content type. Similar shape to LatestNews but rendered with a
// hero-cell-plus-three-thumbnails layout (per the Decode home mockup's
// "Feature Stories" slider — Part 4 ships the no-JS CSS version).

interface FeatureStoriesFields {
  title?: string;
  eyebrow?: string;
}
interface FeatureStoriesOptions {
  content_type?: string;
  category?: string;
  count?: number;
}
const HARD_MAX_COUNT = 8;

export const featureStories: Block<
  FeatureStoriesFields,
  FeatureStoriesOptions
> = {
  meta: {
    key: 'feature-stories',
    label: 'Feature stories',
    category: 'lists',
    description:
      'A compact feature-row of the latest stories — one big card plus thumbnails.',
    icon: 'newspaper',
    fields: [
      { key: 'eyebrow', label: 'Eyebrow', type: 'short_text' },
      {
        key: 'title',
        label: 'Section title',
        type: 'short_text',
        default: 'Feature Stories',
      },
    ],
    options: [
      {
        key: 'content_type',
        label: 'Content type',
        type: 'content_type_slug',
        required: true,
        default: 'article',
      },
      {
        key: 'category',
        label: 'Category filter',
        type: 'category_slug',
        helpText: 'Optional — leave blank to pull from every category.',
      },
      {
        key: 'count',
        label: 'Number of stories',
        type: 'number',
        required: true,
        default: 4,
        min: 1,
        max: HARD_MAX_COUNT,
      },
    ],
  },
  async load(ctx, { options }) {
    const typeSlug = options.content_type ?? 'article';
    const requested = Number.isFinite(options.count) ? Number(options.count) : 4;
    const count = Math.max(1, Math.min(HARD_MAX_COUNT, requested));
    const items = await ctx.fetchArchive({
      typeSlug,
      ...(options.category ? { category: options.category } : {}),
      count,
    });
    return { items };
  },
};
