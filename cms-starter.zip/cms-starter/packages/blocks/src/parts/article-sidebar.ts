import type { TemplateMeta } from '../types.js';

// The `article-sidebar` PART — the article page's right rail as a named
// block-list with the 'sidebar' role, mounted by ArticleView's right grid
// column (the sticky <aside> shell stays view chrome). Two cards: the
// compact newsletter CTA and the editor-notes slider panel.
export const articleSidebarPart: TemplateMeta = {
  key: 'article-sidebar',
  role: 'sidebar',
  name: 'Article Sidebar',
  description:
    'The article right rail: newsletter signup card + editor-notes slider.',
  blocks: [
    {
      block_key: 'sidebar-newsletter',
      default_fields: {
        label: 'Newsletter',
        title: 'Decode in Your Inbox',
        text: 'Investigations, explainers, and occasional notes from our reporters — sent when the work warrants it. Free.',
        button_label: 'Subscribe',
        signup_email: 'subscribe@decode.in',
        note: 'No spam. Unsubscribe anytime.',
      },
      default_options: {},
    },
    {
      block_key: 'editor-notes-panel',
      default_fields: {},
      default_options: {},
    },
  ],
};
