import type { TemplateMeta } from '../types.js';

// The `footer` PART — a named, reusable block-list with the reserved
// 'footer' role, mounted by the layout (see parts/header.ts). Two bands:
// the columns grid and the bottom bar — each visual band is one block so
// the structure editor can reorder/remove them, while the bands' insides
// stay coarse for pixel parity.
export const footerPart: TemplateMeta = {
  key: 'footer',
  role: 'footer',
  name: 'Footer',
  description:
    'The site-wide footer: brand + link columns + newsletter, and the bottom bar.',
  blocks: [
    {
      block_key: 'footer-columns',
      default_fields: {
        about_text:
          'Decode is an independent investigative publication examining how technology shapes power, labour, childhood, identity, and truth in India. Reader-supported. Editorially independent.',
        twitter_url: '#',
        instagram_url: '#',
        youtube_url: '#',
        newsletter_heading: 'Stay Updated',
        newsletter_email: 'subscribe@decode.in',
      },
      default_options: { menu_slug: 'footer-nav' },
    },
    {
      block_key: 'footer-bottom',
      default_fields: {
        copyright_text: 'Decode. A BOOM initiative. All rights reserved.',
        contact_email: 'corrections@decode.in',
      },
      default_options: {},
    },
  ],
};
