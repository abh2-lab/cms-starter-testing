import type { TemplateMeta } from '../types.js';

// The `header` PART — a named, reusable block-list with the reserved
// 'header' role. Parts are TemplateMeta entries like templates, but they are
// mounted by the LAYOUT (via GET /api/public/parts/:key + useCmsPart) rather
// than selected per-route by resolveTemplate. Two blocks: the site-nav
// organism (see its definition for why the header stays coarse) plus the
// search-overlay modal — a global, fixed-position dialog (Teleport-to-body)
// opened by the nav's search button via shared useSearchOverlay state.
export const headerPart: TemplateMeta = {
  key: 'header',
  role: 'header',
  name: 'Header',
  description:
    'The site-wide header: logo, menu navigation, and action buttons.',
  // Bumped to 2 when the search-overlay block was added alongside site-nav, so
  // installs carrying a saved header override surface an "update available".
  version: 2,
  blocks: [
    {
      block_key: 'site-nav',
      default_fields: {
        subscribe_label: 'Subscribe',
        signin_label: 'Sign In',
      },
      default_options: {
        menu_slug: 'main-nav',
        show_subscribe: true,
        show_search: true,
        show_signin: true,
      },
    },
    {
      // The "What are you looking for?" search modal. Standalone, position:fixed
      // + Teleport-to-body, so its place in the block list doesn't matter — it
      // covers the viewport when the site-nav search button opens it (shared
      // useSearchOverlay state) and submits to /search.
      block_key: 'search-overlay',
      default_fields: {
        heading: 'What are you looking for?',
        placeholder: 'Search stories, topics, authors…',
        button_label: 'Search',
        categories_label: 'Popular Categories',
        spotlight_label: 'Spotlight',
        categories: [
          { label: '🧠 Young Minds', value: 'young-minds' },
          { label: '🏛️ Digital State', value: 'digital-state' },
          { label: '⚙️ Labour', value: 'labour' },
          { label: '🌿 Life', value: 'life' },
          { label: '💡 Decode Explains', value: 'decode-explains' },
          { label: '🎙️ Voices', value: 'voices' },
        ],
      },
      default_options: {
        spotlight_content_type: 'article',
        spotlight_slug: 'bangladeshis-west-bengal',
      },
    },
  ],
};
