import type { Block, TemplateMeta, TemplateRole } from './types.js';
import { hero } from './blocks/hero.js';
import { latestNews } from './blocks/latest-news.js';
import { featuredArticle } from './blocks/featured-article.js';
import { impactStats } from './blocks/impact-stats.js';
import { heroFeatured } from './blocks/hero-featured.js';
import { featureStories } from './blocks/feature-stories.js';
import { editorNotes } from './blocks/editor-notes.js';
import { categoryStrip } from './blocks/category-strip.js';
import { newsletterCta } from './blocks/newsletter-cta.js';
// Theme-engine v1: field, container, and box blocks (FSE-style primitives).
import { postTitle } from './blocks/post-title.js';
import { postContent } from './blocks/post-content.js';
import { featuredImage } from './blocks/featured-image.js';
import { publishedAt } from './blocks/published-at.js';
import { postAuthor } from './blocks/post-author.js';
import { customField } from './blocks/custom-field.js';
import { archiveTitle } from './blocks/archive-title.js';
import { group } from './blocks/group.js';
import { queryLoop } from './blocks/query-loop.js';
import { post } from './blocks/post.js';
// Theme-engine v1.5: archive re-blocking (post card + archive chrome).
import { postCard } from './blocks/post-card.js';
import { archiveHero } from './blocks/archive-hero.js';
import { archiveManifesto } from './blocks/archive-manifesto.js';
import { dispatchBox } from './blocks/dispatch-box.js';
import { editorNotesColumn } from './blocks/editor-notes-column.js';
// Theme-engine v1.5: site chrome (header/footer parts).
import { siteNav } from './blocks/site-nav.js';
import { footerColumns } from './blocks/footer-columns.js';
import { footerBottom } from './blocks/footer-bottom.js';
// Theme-engine v1.5: article chrome re-blocking.
import { postHero } from './blocks/post-hero.js';
import { editorialNote } from './blocks/editorial-note.js';
import { articleToc } from './blocks/article-toc.js';
import { postTags } from './blocks/post-tags.js';
import { editorCredit } from './blocks/editor-credit.js';
import { relatedPosts } from './blocks/related-posts.js';
import { authorBios } from './blocks/author-bios.js';
import { sidebarNewsletter } from './blocks/sidebar-newsletter.js';
import { editorNotesPanel } from './blocks/editor-notes-panel.js';
// Events page blocks (the /events page is now dynamic).
import { eventsHero } from './blocks/events-hero.js';
import { pastEvents } from './blocks/past-events.js';
import { eventsCta } from './blocks/events-cta.js';
// Theme-engine v2 Phase 4: system pages (404/search/authors/contact) as
// override-backed templates — the blocks that carry their editable bodies.
import { notFound } from './blocks/not-found.js';
import { searchForm } from './blocks/search-form.js';
import { searchResults } from './blocks/search-results.js';
import { authorGrid } from './blocks/author-grid.js';
import { contactForm } from './blocks/contact-form.js';
// <gen:block-imports> — `pnpm gen:block` inserts new block imports here. Keep this marker.
import { searchOverlay } from './blocks/search-overlay.js';
// </gen:block-imports>
import { homeDefault } from './templates/home-default.js';
import { homeDecode } from './templates/home-decode.js';
import { staticTextpage } from './templates/static-textpage.js';
import { singleArticle } from './templates/single.js';
import { archiveDefault } from './templates/archive.js';
import { archiveCategory } from './templates/archive-category.js';
import { archiveTag } from './templates/archive-tag.js';
import { searchTemplate } from './templates/search.js';
import { notFoundTemplate } from './templates/not-found.js';
import { authorsTemplate } from './templates/authors.js';
import { contactTemplate } from './templates/contact.js';
// <gen:template-imports> — `pnpm gen:template` inserts new template imports here. Keep this marker.
// </gen:template-imports>
import { headerPart } from './parts/header.js';
import { footerPart } from './parts/footer.js';
import { articleSidebarPart } from './parts/article-sidebar.js';
// <gen:part-imports> — `pnpm gen:template` inserts new part imports here. Keep this marker.
// </gen:part-imports>

// Two map-shaped registries the API + admin endpoints read at request time.
// Keep adding new blocks/templates HERE — putting the imports in the entry
// file keeps tree-shaking predictable and the manifest CI-grep-able.
//
// Cast to `Block` because the per-block generic types vary; the registry only
// needs to expose the structural shape. Loaders are still called type-safely
// by their own files (we don't widen there — we widen at the registry boundary).

export const blockRegistry: ReadonlyMap<string, Block> = new Map<string, Block>([
  [hero.meta.key, hero],
  [heroFeatured.meta.key, heroFeatured],
  [latestNews.meta.key, latestNews],
  [featureStories.meta.key, featureStories],
  [editorNotes.meta.key, editorNotes],
  [featuredArticle.meta.key, featuredArticle],
  [impactStats.meta.key, impactStats],
  [categoryStrip.meta.key, categoryStrip],
  [newsletterCta.meta.key, newsletterCta],
  // FSE-style primitives — field/container/box blocks.
  [postTitle.meta.key, postTitle],
  [postContent.meta.key, postContent],
  [featuredImage.meta.key, featuredImage],
  [publishedAt.meta.key, publishedAt],
  [postAuthor.meta.key, postAuthor],
  [customField.meta.key, customField],
  [archiveTitle.meta.key, archiveTitle],
  [group.meta.key, group],
  [queryLoop.meta.key, queryLoop],
  [post.meta.key, post],
  // Archive re-blocking (v1.5).
  [postCard.meta.key, postCard],
  [archiveHero.meta.key, archiveHero],
  [archiveManifesto.meta.key, archiveManifesto],
  [dispatchBox.meta.key, dispatchBox],
  [editorNotesColumn.meta.key, editorNotesColumn],
  // Site chrome (v1.5 parts).
  [siteNav.meta.key, siteNav],
  [footerColumns.meta.key, footerColumns],
  [footerBottom.meta.key, footerBottom],
  // Article chrome (v1.5).
  [postHero.meta.key, postHero],
  [editorialNote.meta.key, editorialNote],
  [articleToc.meta.key, articleToc],
  [postTags.meta.key, postTags],
  [editorCredit.meta.key, editorCredit],
  [relatedPosts.meta.key, relatedPosts],
  [authorBios.meta.key, authorBios],
  [sidebarNewsletter.meta.key, sidebarNewsletter],
  [editorNotesPanel.meta.key, editorNotesPanel],
  // Events page blocks.
  [eventsHero.meta.key, eventsHero],
  [pastEvents.meta.key, pastEvents],
  [eventsCta.meta.key, eventsCta],
  // System-page blocks (v2 Phase 4): 404 / search / authors / contact.
  [notFound.meta.key, notFound],
  [searchForm.meta.key, searchForm],
  [searchResults.meta.key, searchResults],
  [authorGrid.meta.key, authorGrid],
  [contactForm.meta.key, contactForm],
  // <gen:block-registry> — `pnpm gen:block` inserts new block entries here. Keep this marker.
  [searchOverlay.meta.key, searchOverlay],
  // </gen:block-registry>
]);

export const templateRegistry: ReadonlyMap<string, TemplateMeta> = new Map<
  string,
  TemplateMeta
>([
  [homeDefault.key, homeDefault],
  [homeDecode.key, homeDecode],
  [staticTextpage.key, staticTextpage],
  // <gen:template-registry> — `pnpm gen:template` inserts new page-template entries here. Keep this marker.
  // </gen:template-registry>
]);

// Convenience helpers used by the API endpoints.

export function getBlock(key: string): Block | undefined {
  return blockRegistry.get(key);
}

export function getTemplate(key: string): TemplateMeta | undefined {
  return templateRegistry.get(key);
}

export function listBlockMetas(): Array<Block['meta']> {
  return Array.from(blockRegistry.values()).map((b) => b.meta);
}

export function listTemplates(): TemplateMeta[] {
  return Array.from(templateRegistry.values());
}

// ─── Role-indexed templates (the template hierarchy) ──────────────────────
//
// All role-tagged templates — the admin page templates PLUS the engine
// templates (single, archive). Kept separate from `templateRegistry` (the
// admin's page-template browse set) so single/archive don't surface in the
// "+ New Page" picker. resolveTemplate() and v2's template UI read this.
const roleTemplates: ReadonlyArray<TemplateMeta> = [
  homeDefault,
  homeDecode,
  staticTextpage,
  singleArticle,
  archiveDefault,
  archiveCategory,
  archiveTag,
  // System-page templates (v2 Phase 4) — role-resolved + overridable.
  searchTemplate,
  notFoundTemplate,
  authorsTemplate,
  contactTemplate,
  // <gen:role-templates> — `pnpm gen:template` inserts new role-template entries here. Keep this marker.
  // </gen:role-templates>
];

export function getTemplatesByRole(role: TemplateRole): TemplateMeta[] {
  return roleTemplates.filter((t) => t.role === role);
}

// ─── Parts (template-parts) ────────────────────────────────────────────────
//
// Named, reusable block-lists with the reserved layout roles (header/footer/
// sidebar). Same TemplateMeta shape as templates, but a separate registry:
// parts are mounted by the LAYOUT / view shells (via /api/public/parts/:key),
// never selected by resolveTemplate, and must not surface in the admin's
// "+ New Page" template picker.
export const partRegistry: ReadonlyMap<string, TemplateMeta> = new Map<
  string,
  TemplateMeta
>([
  [headerPart.key, headerPart],
  [footerPart.key, footerPart],
  [articleSidebarPart.key, articleSidebarPart],
  // <gen:part-registry> — `pnpm gen:template` inserts new part entries here. Keep this marker.
  // </gen:part-registry>
]);

export function getPart(key: string): TemplateMeta | undefined {
  return partRegistry.get(key);
}

export function listParts(): TemplateMeta[] {
  return Array.from(partRegistry.values());
}
